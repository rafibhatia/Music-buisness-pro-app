# Quick Reference Card

## 🚀 One-Line Commands

```bash
# Install everything
npm install

# Run in development (opens desktop window)
npm run electron:dev

# Build for production
npm run build && npm run electron:build
```

## 📁 Essential Files

| File | Purpose |
|------|---------|
| `package.json` | Dependencies & scripts |
| `electron-main.js` | Desktop app entry point |
| `main.tsx` | React entry point |
| `App.tsx` | Main React component |
| `utils/electron.ts` | Desktop detection |
| `.env` | API keys (create from .env.example) |

## 🎯 Build Commands

| Command | Builds For | Output |
|---------|-----------|--------|
| `npm run electron:build` | Current platform | release/ folder |
| `npm run electron:build:win` | Windows | .exe installer |
| `npm run electron:build:mac` | macOS | .dmg installer |
| `npm run electron:build:linux` | Linux | .AppImage, .deb, .rpm |
| `npm run electron:build:all` | All platforms | All installers |

## ✅ Desktop App Features

- ✅ No browser required
- ✅ Runs offline
- ✅ Native window controls
- ✅ File dialogs
- ✅ System notifications
- ✅ Single instance
- ✅ Auto-updates (can enable)
- ✅ Custom protocol (`musicbizpro://`)

## 🔍 How to Verify Desktop Mode

```javascript
// Check in console
console.log(window.electronAPI !== undefined); // Should be true
```

## 📊 File Sizes

- Windows installer: ~100 MB
- macOS DMG: ~120 MB
- Linux AppImage: ~110 MB

## 🎨 Quick Customization

1. **App Name:** Edit `productName` in `electron-builder.json`
2. **App ID:** Edit `appId` in `electron-builder.json`
3. **Icon:** Replace `public/icon.png` (512x512)
4. **Version:** Edit `version` in `package.json`

## 🐛 Quick Fixes

```bash
# Clear and reinstall
rm -rf node_modules package-lock.json && npm install

# Rebuild from scratch
npm run build && npm run electron:build

# Check for errors
npm run electron:dev
```

## 📖 Documentation Quick Links

- `START_HERE.md` - Start here!
- `STANDALONE_DESKTOP_README.md` - Full desktop guide
- `DESKTOP_CHECKLIST.md` - Pre-build checklist
- `NO_BROWSER_REQUIRED.md` - Why it's not a browser app
- `BUILD_WITHOUT_NPM_INSTALL.md` - Complete file list

## 🎯 Three-Step Build Process

```bash
# Step 1: Install dependencies (once)
npm install

# Step 2: Test in development
npm run electron:dev

# Step 3: Build installer
npm run electron:build
```

## ✨ What Makes This Desktop-Only?

1. Electron detects automatically
2. Skips landing page
3. Disables service worker
4. Hides PWA prompts
5. Loads from `file://` not `http://`
6. No server required

## 🎉 Success Indicators

You'll know it's working when:

- ✅ Desktop window opens (not browser tab)
- ✅ Goes straight to dashboard
- ✅ Console shows "Running in Electron environment"
- ✅ Can build installers successfully
- ✅ Installed app works offline

## 💻 Platform-Specific Notes

### Windows
- Installer: NSIS (.exe)
- Portable version included
- Creates Start Menu entry
- Code signing recommended

### macOS
- Installer: DMG disk image
- Supports Intel (x64) + Apple Silicon (arm64)
- Code signing required for distribution
- Notarization recommended

### Linux
- AppImage: Universal (no install needed)
- .deb: Debian/Ubuntu
- .rpm: Fedora/RHEL
- No code signing needed

## 🔒 Security Checklist

- [ ] Never commit `.env` with real API keys
- [ ] Use code signing for production
- [ ] Enable auto-updates for security patches
- [ ] Validate all user inputs
- [ ] Use HTTPS for all API calls

## 📞 Getting Help

1. Check console for errors: `npm run electron:dev`
2. Read error messages carefully
3. Check documentation files
4. Verify all files present
5. Try clean reinstall: `rm -rf node_modules && npm install`

---

**Remember:** This is a DESKTOP APPLICATION, not a website. It runs independently of any web browser! 🚀

**Quick Test:**
```bash
npm install && npm run electron:dev
```

If a desktop window opens showing the dashboard, you're all set! ✨
