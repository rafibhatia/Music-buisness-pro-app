# Electron Setup Guide for Music Biz Pro

## 🚀 Quick Start

This guide will help you set up and run Music Biz Pro as a native desktop application using Electron.

## 📋 Prerequisites

- Node.js (v18 or higher) - [Download](https://nodejs.org/)
- npm or yarn package manager
- Git (optional)

## 🔧 Installation Steps

### 1. Export the Project

First, export all files from Figma Make to your local machine.

### 2. Install Dependencies

Open a terminal in your project directory and run:

```bash
npm install
```

This will install all dependencies including:
- React and related packages
- Vite (build tool)
- Electron
- Electron Builder
- All UI libraries

### 3. Run in Development Mode

#### Option A: Web Browser Development (Recommended for testing)
```bash
npm run dev
```
Then open http://localhost:5173 in your browser.

#### Option B: Electron Development Mode
```bash
npm run electron:dev
```
This will:
1. Start the Vite dev server
2. Wait for it to be ready
3. Launch the Electron app

### 4. Build for Production

#### Build Web Version First
```bash
npm run build
```

#### Build Desktop Installers

**For Windows (.exe):**
```bash
npm run electron:build:win
```

**For macOS (.dmg):**
```bash
npm run electron:build:mac
```

**For Linux (.AppImage, .deb, .rpm):**
```bash
npm run electron:build:linux
```

**For All Platforms:**
```bash
npm run electron:build:all
```

## 📁 Project Structure

```
music-biz-pro/
├── electron-main.js           # Electron main process
├── electron-preload.js        # Preload script (security)
├── electron-builder.json      # Build configuration
├── package.json               # Dependencies and scripts
├── vite.config.ts            # Vite configuration
├── src/                      # React source code
│   ├── App.tsx              # Main React component
│   ├── components/          # All React components
│   └── styles/              # CSS files
├── public/                   # Static assets
│   └── icon.png             # App icon (you'll need to add this)
└── dist/                     # Built files (after npm run build)
```

## 🎯 Available Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start Vite dev server (web browser) |
| `npm run build` | Build React app for production |
| `npm run electron` | Run Electron with built files |
| `npm run electron:dev` | Run Electron in development mode |
| `npm run electron:build` | Build installer for current platform |
| `npm run electron:build:win` | Build Windows installer |
| `npm run electron:build:mac` | Build macOS installer |
| `npm run electron:build:linux` | Build Linux installers |
| `npm run pack` | Build unpacked directory (for testing) |

## 🖼️ Adding App Icons

You need to create icons for your app:

### Required Icon Files

**Windows:**
- `public/icon.png` (256x256 or larger, PNG)
- Optionally: `build/icon.ico`

**macOS:**
- `public/icon.png` (512x512 or 1024x1024, PNG)
- Optionally: `build/icon.icns`

**Linux:**
- `public/icon.png` (512x512 or larger, PNG)

### Quick Icon Generation

Use online tools to generate icons:
- [IconGenerator](https://www.icongenerator.com/)
- [Electron Icon Maker](https://github.com/jaretburkett/electron-icon-maker)

Or create them manually:
1. Design a 1024x1024 PNG icon
2. Save as `public/icon.png`
3. Electron Builder will handle conversions

## 🔐 Security Best Practices

The Electron configuration includes:

✅ **Node Integration**: Disabled (prevents security risks)
✅ **Context Isolation**: Enabled (protects renderer process)
✅ **Preload Script**: Secure IPC communication
✅ **Remote Module**: Disabled (deprecated and insecure)
✅ **External Links**: Open in default browser, not in app

## 🎨 Customizing the Build

### Update App Information

Edit `package.json`:
```json
{
  "name": "music-biz-pro",
  "version": "1.0.0",
  "description": "Your description",
  "author": {
    "name": "Your Name",
    "email": "your.email@example.com"
  }
}
```

Edit `electron-builder.json`:
```json
{
  "appId": "com.yourcompany.musicbizpro",
  "productName": "Your App Name"
}
```

### Window Customization

Edit `electron-main.js`:
```javascript
mainWindow = new BrowserWindow({
  width: 1400,        // Change default width
  height: 900,        // Change default height
  minWidth: 1200,     // Minimum width
  minHeight: 700,     // Minimum height
  // ... other options
});
```

## 📦 Build Outputs

After building, find your installers in the `release/` directory:

**Windows:**
- `MusicBizPro-1.0.0-x64.exe` (NSIS installer)
- `MusicBizPro-1.0.0-x64.exe` (Portable version)

**macOS:**
- `MusicBizPro-1.0.0-arm64.dmg` (Apple Silicon)
- `MusicBizPro-1.0.0-x64.dmg` (Intel)

**Linux:**
- `MusicBizPro-1.0.0-x86_64.AppImage`
- `MusicBizPro-1.0.0-amd64.deb`
- `MusicBizPro-1.0.0-x86_64.rpm`

## 🐛 Troubleshooting

### Issue: "electron: command not found"

**Solution:**
```bash
npm install --save-dev electron
```

### Issue: Build fails on macOS (code signing)

**Solution:**
Temporarily disable code signing by adding to `electron-builder.json`:
```json
{
  "mac": {
    "identity": null
  }
}
```

### Issue: "Cannot find module 'electron-is-dev'"

**Solution:**
```bash
npm install --save-dev electron-is-dev
```

### Issue: App window is blank

**Solutions:**
1. Make sure you ran `npm run build` first
2. Check the console for errors with DevTools
3. Verify the `dist/` folder exists with built files

### Issue: Port 5173 already in use

**Solution:**
Kill the process using that port:
```bash
# macOS/Linux
lsof -ti:5173 | xargs kill -9

# Windows
netstat -ano | findstr :5173
taskkill /PID <PID> /F
```

## 🔄 Development Workflow

### Recommended Development Process:

1. **Start Development Server:**
   ```bash
   npm run dev
   ```
   Test in browser first (faster hot reload)

2. **Test in Electron:**
   ```bash
   npm run electron:dev
   ```
   Test desktop-specific features

3. **Build and Test:**
   ```bash
   npm run build
   npm run electron
   ```
   Test production build before creating installer

4. **Create Installer:**
   ```bash
   npm run electron:build
   ```
   Create final distributable

## 🌟 Advanced Features

### Auto-Updates (Optional)

The `electron-main.js` file includes commented code for auto-updates. To enable:

1. Uncomment the auto-updater code in `electron-main.js`
2. Install `electron-updater`:
   ```bash
   npm install electron-updater
   ```
3. Configure your update server
4. Rebuild the app

### Custom Protocol Handler

The app registers `musicbizpro://` protocol. Use it for deep linking:
```javascript
// Open the app with a specific view
musicbizpro://contacts
musicbizpro://bookings
```

### Native Notifications

Use the Electron API exposed through the preload script:
```javascript
if (window.electronAPI) {
  window.electronAPI.requestNotificationPermission();
}
```

## 📊 Performance Tips

1. **Reduce Bundle Size:**
   - Remove unused dependencies
   - Use code splitting
   - Optimize images

2. **Faster Builds:**
   - Use `npm run pack` for testing (skips compression)
   - Build for specific platform only during development

3. **Development Speed:**
   - Use browser development (`npm run dev`) for UI work
   - Use Electron only when testing desktop features

## 🚢 Distribution

### Windows:
- Users can download and run the `.exe` installer
- For Microsoft Store: Convert to APPX/MSIX format

### macOS:
- Distribute `.dmg` file
- For Mac App Store: Additional steps required (Apple Developer account)
- Code signing recommended for distribution

### Linux:
- `.AppImage` works on most distributions (no installation)
- `.deb` for Debian/Ubuntu
- `.rpm` for Fedora/RedHat/CentOS

## 📝 Notes

- **First Build:** The first build takes longer (5-15 minutes)
- **Disk Space:** Build artifacts can be large (200-500MB per platform)
- **Cross-Platform Building:** Windows can only build for Windows. macOS needed for macOS builds.
- **Testing:** Always test installers on clean machines

## 🆘 Need Help?

Common resources:
- [Electron Documentation](https://www.electronjs.org/docs)
- [Electron Builder Docs](https://www.electron.build/)
- [Vite Documentation](https://vitejs.dev/)

## ✅ Checklist Before Building

- [ ] All dependencies installed (`npm install`)
- [ ] App icon created (`public/icon.png`)
- [ ] Package.json info updated (name, author, version)
- [ ] App tested in dev mode (`npm run electron:dev`)
- [ ] Production build tested (`npm run build && npm run electron`)
- [ ] Build configuration reviewed (`electron-builder.json`)
- [ ] Ready to create installer!

## 🎉 Success!

Once you run `npm run electron:build`, your native desktop application will be in the `release/` folder, ready to distribute!

---

**Enjoy your Music Biz Pro desktop app!** 🎵
