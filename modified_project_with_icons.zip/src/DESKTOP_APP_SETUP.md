# Desktop Application Setup Guide

## Overview

This Music Biz Pro application is designed to run as a **standalone desktop application** using Electron. When built as a desktop app, it will:

✅ Run independently without a web browser
✅ Launch directly to the main application interface
✅ Provide native desktop features (window controls, file dialogs, notifications)
✅ Work offline by default
✅ Install as a native application (.exe, .dmg, .AppImage)

## Key Features for Desktop Mode

### Automatic Desktop Detection

The application automatically detects when it's running in Electron and:
- Skips the landing page and goes directly to the app
- Disables PWA service worker registration
- Hides browser-specific install prompts
- Enables Electron-specific features via the `electronAPI`

### Native Desktop Features

When running as a desktop app, you get:
- **Native window controls** (minimize, maximize, close)
- **File dialogs** for opening and saving files
- **System notifications** (automatically granted)
- **Custom protocol handler** (`musicbizpro://` URLs)
- **Single instance lock** (prevents multiple app instances)
- **Auto-update capability** (can be enabled in electron-main.js)

## Installation Steps

### 1. Install Dependencies

```bash
npm install
```

This will install all required packages including:
- Electron
- Electron Builder (for creating installers)
- Vite (for building the React app)
- All React and UI dependencies

### 2. Development Mode

Run the app in development mode with hot reload:

```bash
npm run electron:dev
```

This command:
1. Starts the Vite dev server on port 5173
2. Waits for the server to be ready
3. Launches Electron pointing to the dev server
4. Enables hot reload for quick development

### 3. Build Production Version

Build the React app for production:

```bash
npm run build
```

This creates an optimized build in the `dist/` folder.

### 4. Create Desktop Installers

#### Windows (.exe)
```bash
npm run electron:build:win
```
Creates:
- NSIS installer (with installation wizard)
- Portable executable

Output: `release/MusicBizPro-{version}-x64.exe`

#### macOS (.dmg)
```bash
npm run electron:build:mac
```
Creates:
- DMG disk image
- ZIP archive
- Supports both Intel (x64) and Apple Silicon (arm64)

Output: `release/MusicBizPro-{version}-{arch}.dmg`

#### Linux (.AppImage, .deb, .rpm)
```bash
npm run electron:build:linux
```
Creates:
- AppImage (universal)
- Debian package (.deb)
- RPM package (.rpm)

Output: `release/MusicBizPro-{version}-{arch}.{ext}`

#### All Platforms
```bash
npm run electron:build:all
```
Builds installers for Windows, macOS, and Linux.

## File Structure

### Core Files

```
├── electron-main.js        # Electron main process
├── electron-preload.js     # Preload script for security
├── electron-builder.json   # Build configuration
├── package.json           # Dependencies and scripts
├── vite.config.ts         # Vite configuration
├── main.tsx              # React entry point
├── App.tsx               # Main React component
└── utils/
    └── electron.ts       # Electron detection utilities
```

### Build Output

```
├── dist/                 # Built React app
└── release/             # Built installers
    ├── *.exe           # Windows installers
    ├── *.dmg           # macOS installers
    ├── *.AppImage      # Linux AppImage
    ├── *.deb           # Debian package
    └── *.rpm           # RPM package
```

## Configuration

### Application Identity

Edit `electron-builder.json` to customize:
- `appId`: Unique app identifier (e.g., "com.yourcompany.musicbizpro")
- `productName`: Display name of the app
- Icons and installer settings

### Application Icons

Place your application icons in the `public/` folder:
- `icon.png` - Main application icon (512x512 or larger)
- For best results, use PNG format with transparency

### Custom Protocol

The app registers the `musicbizpro://` protocol, allowing deep linking:
- Example: `musicbizpro://open/project/123`
- Handled in `electron-main.js` (currently logs the URL)

## Environment Variables

Create a `.env` file for API keys (Supabase, Twilio, SendGrid):

```bash
cp .env.example .env
```

Edit `.env` with your actual credentials:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_key
VITE_TWILIO_ACCOUNT_SID=your_twilio_sid
VITE_TWILIO_AUTH_TOKEN=your_twilio_token
VITE_SENDGRID_API_KEY=your_sendgrid_key
```

**Important:** Never commit the `.env` file with real credentials to version control.

## Electron vs Browser Behavior

### Electron (Desktop App)
- ✅ Launches directly to main app
- ✅ No service worker
- ✅ No install prompts
- ✅ Native window controls
- ✅ File system access
- ✅ System notifications

### Browser (Web App)
- Shows landing page on first visit
- Registers service worker for offline support
- Shows PWA install prompt
- Standard browser controls
- Limited file system access
- Requires notification permission

## Security Considerations

### Context Isolation
The app uses Electron's security best practices:
- `nodeIntegration: false` - Node.js not available in renderer
- `contextIsolation: true` - Isolates preload script context
- `enableRemoteModule: false` - Remote module disabled
- Preload script provides safe IPC bridge

### Safe Communication
Use the `electronAPI` in your React components:
```typescript
if (window.electronAPI) {
  const version = await window.electronAPI.getAppVersion();
  window.electronAPI.openExternal('https://example.com');
}
```

## Distribution

### Code Signing (Recommended)

For production distribution, you should code sign your application:

**Windows:**
- Get a code signing certificate
- Set environment variables:
  ```
  CSC_LINK=path/to/certificate.pfx
  CSC_KEY_PASSWORD=your_password
  ```

**macOS:**
- Enroll in Apple Developer Program
- Get a Developer ID Application certificate
- Set environment variables:
  ```
  CSC_LINK=path/to/certificate.p12
  CSC_KEY_PASSWORD=your_password
  APPLE_ID=your_apple_id
  APPLE_ID_PASSWORD=app_specific_password
  ```

**Linux:**
- No code signing required

### Auto-Updates (Optional)

To enable auto-updates:
1. Uncomment the auto-updater code in `electron-main.js`
2. Set up a release server or use GitHub Releases
3. Configure `publish` settings in `electron-builder.json`

## Troubleshooting

### Build Fails
- Ensure all dependencies are installed: `npm install`
- Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`
- Check Node.js version: `node --version` (should be 18+ or 20+)

### App Won't Start
- Check console for errors: `npm run electron:dev`
- Verify port 5173 is not in use
- Check that `dist/` folder exists after build

### Icons Not Showing
- Ensure icon files exist in `public/` folder
- Icons should be PNG format, 512x512 or larger
- Rebuild the app after adding new icons

### Environment Variables Not Working
- Ensure `.env` file is in root directory
- Variables must start with `VITE_` prefix
- Restart dev server after changing `.env`

## Additional Resources

- [Electron Documentation](https://www.electronjs.org/docs)
- [Electron Builder Documentation](https://www.electron.build/)
- [Vite Documentation](https://vitejs.dev/)

## Support

For issues specific to the Music Biz Pro application, refer to:
- `FEATURES.md` - Complete feature list
- `ELECTRON_SETUP.md` - Detailed Electron configuration
- `README.md` - General project information

---

**Note:** This application is designed for prototyping and development. For production use with real user data, ensure proper security measures, data encryption, and compliance with relevant regulations.
