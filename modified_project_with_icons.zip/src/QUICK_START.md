# 🚀 Quick Start Guide

Get Music Biz Pro running on your local machine in minutes!

## ⚡ Super Quick Start (3 Commands)

```bash
# 1. Install dependencies
npm install

# 2. Run in development
npm run electron:dev

# 3. Build desktop app
npm run electron:build
```

## 📝 Detailed Steps

### Step 1: Prerequisites

Make sure you have Node.js installed:
- Download from https://nodejs.org/
- Version 18 or higher recommended

Check your version:
```bash
node --version
npm --version
```

### Step 2: Export & Setup

1. Export all files from Figma Make to a folder
2. Open terminal/command prompt in that folder
3. Run: `npm install`

Wait 2-5 minutes for all packages to install.

### Step 3: Run the App

**For Development (with hot reload):**
```bash
npm run electron:dev
```

**For Testing Web Version:**
```bash
npm run dev
```
Then open http://localhost:5173

### Step 4: Create Desktop Installer

```bash
# Build for your current platform
npm run electron:build

# Or build for specific platform
npm run electron:build:win    # Windows
npm run electron:build:mac    # macOS  
npm run electron:build:linux  # Linux
```

Your installer will be in the `release/` folder!

## 🎨 Before Building - Add App Icon

Create an icon and save as `public/icon.png`:
- Minimum: 256x256 pixels
- Recommended: 512x512 or 1024x1024 pixels
- Format: PNG with transparency

Quick icon tools:
- Canva (online)
- GIMP (free)
- Photoshop

## 🎯 What You Get

After building, you'll have:

**Windows:**
- `.exe` installer (double-click to install)
- Portable `.exe` (no installation needed)

**macOS:**
- `.dmg` installer (drag to Applications)
- Universal or platform-specific builds

**Linux:**
- `.AppImage` (run anywhere)
- `.deb` (Ubuntu/Debian)
- `.rpm` (Fedora/RedHat)

## 💡 Tips

1. **First time?** Start with `npm run dev` to test in browser first
2. **Making changes?** Use `npm run electron:dev` for live reloading
3. **Ready to share?** Run `npm run electron:build` to create installer
4. **Build failed?** Check you ran `npm install` successfully

## 🐛 Quick Troubleshooting

**Problem:** Commands don't work
**Solution:** Make sure you're in the project folder and ran `npm install`

**Problem:** Port 5173 in use
**Solution:** Close other apps or change port in `vite.config.ts`

**Problem:** Electron window is blank  
**Solution:** Run `npm run build` first, then `npm run electron`

**Problem:** Build takes forever
**Solution:** Normal! First build takes 5-15 minutes. Grab coffee ☕

## 📚 More Help

- Full setup guide: `ELECTRON_SETUP.md`
- All features: `FEATURES.md`
- Native packaging: `NATIVE_PACKAGING_GUIDE.md`

## ✅ Success Checklist

- [ ] Node.js installed (v18+)
- [ ] Downloaded/exported all files
- [ ] Ran `npm install` successfully
- [ ] App runs with `npm run electron:dev`
- [ ] App icon created (`public/icon.png`)
- [ ] Built installer with `npm run electron:build`
- [ ] Tested installer on your computer
- [ ] Ready to share! 🎉

---

**That's it! You now have a native desktop application.** 🎵

Need more details? Check `ELECTRON_SETUP.md` for the complete guide.
