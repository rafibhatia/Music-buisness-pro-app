#!/bin/bash

# Music Biz Pro - Desktop Application Build Script
# This script builds the desktop application installers

set -e  # Exit on error

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║        Music Biz Pro - Desktop Application Builder            ║"
echo "║                                                                ║"
echo "║  This script will build standalone desktop installers         ║"
echo "║  that DO NOT require a web browser to run.                    ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed!${NC}"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm is not installed!${NC}"
    echo "Please install npm (comes with Node.js)"
    exit 1
fi

echo -e "${GREEN}✓${NC} Node.js version: $(node --version)"
echo -e "${GREEN}✓${NC} npm version: $(npm --version)"
echo ""

# Function to check if dependencies are installed
check_dependencies() {
    if [ ! -d "node_modules" ]; then
        echo -e "${YELLOW}⚠${NC}  Dependencies not installed"
        return 1
    fi
    return 0
}

# Function to install dependencies
install_dependencies() {
    echo -e "${BLUE}📦 Installing dependencies...${NC}"
    npm install
    echo -e "${GREEN}✓${NC} Dependencies installed"
    echo ""
}

# Function to build React app
build_react_app() {
    echo -e "${BLUE}🔨 Building React application...${NC}"
    npm run build
    
    if [ ! -d "dist" ]; then
        echo -e "${RED}❌ Build failed - dist folder not created${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓${NC} React app built successfully"
    echo ""
}

# Function to build Electron app
build_electron_app() {
    local platform=$1
    
    echo -e "${BLUE}🖥️  Building Electron installer for $platform...${NC}"
    
    case $platform in
        "current")
            npm run electron:build
            ;;
        "windows")
            npm run electron:build:win
            ;;
        "macos")
            npm run electron:build:mac
            ;;
        "linux")
            npm run electron:build:linux
            ;;
        "all")
            npm run electron:build:all
            ;;
        *)
            echo -e "${RED}❌ Unknown platform: $platform${NC}"
            exit 1
            ;;
    esac
    
    echo -e "${GREEN}✓${NC} Electron installer built successfully"
    echo ""
}

# Function to show build results
show_results() {
    if [ -d "release" ]; then
        echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${GREEN}║                    BUILD SUCCESSFUL! 🎉                        ║${NC}"
        echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
        echo ""
        echo -e "${BLUE}📦 Installers created in 'release/' folder:${NC}"
        echo ""
        
        # List all files in release folder
        ls -lh release/ | grep -v "^total" | grep -v "^d" | awk '{print "   " $9 " (" $5 ")"}'
        
        echo ""
        echo -e "${YELLOW}Next steps:${NC}"
        echo "  1. Navigate to the 'release/' folder"
        echo "  2. Distribute the installer for your target platform"
        echo "  3. Users can install and run WITHOUT a web browser!"
        echo ""
        echo -e "${BLUE}Platform-specific installers:${NC}"
        echo "  • Windows: .exe files (NSIS installer + Portable)"
        echo "  • macOS:   .dmg and .zip files (x64 + arm64)"
        echo "  • Linux:   .AppImage, .deb, .rpm files"
        echo ""
    else
        echo -e "${RED}❌ Build failed - release folder not created${NC}"
        exit 1
    fi
}

# Main menu
main_menu() {
    echo "Select build target:"
    echo ""
    echo "  1) Current platform only (fastest)"
    echo "  2) Windows (.exe)"
    echo "  3) macOS (.dmg)"
    echo "  4) Linux (.AppImage, .deb, .rpm)"
    echo "  5) All platforms (Windows + macOS + Linux)"
    echo "  6) Exit"
    echo ""
    read -p "Enter your choice (1-6): " choice
    
    case $choice in
        1)
            PLATFORM="current"
            ;;
        2)
            PLATFORM="windows"
            ;;
        3)
            PLATFORM="macos"
            ;;
        4)
            PLATFORM="linux"
            ;;
        5)
            PLATFORM="all"
            ;;
        6)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo -e "${RED}Invalid choice${NC}"
            exit 1
            ;;
    esac
}

# Run the build process
main() {
    # Check if running with --auto flag (skip menu)
    if [ "$1" == "--auto" ]; then
        PLATFORM=${2:-current}
    else
        main_menu
    fi
    
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Starting build process for: $PLATFORM${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Check and install dependencies if needed
    if ! check_dependencies; then
        install_dependencies
    else
        echo -e "${GREEN}✓${NC} Dependencies already installed"
        echo ""
    fi
    
    # Build React app
    build_react_app
    
    # Build Electron app
    build_electron_app "$PLATFORM"
    
    # Show results
    show_results
    
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}Build complete!${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
}

# Run main function
main "$@"
