/**
 * Electron detection and utilities
 */

export const isElectron = (): boolean => {
  // Check if running in Electron
  return !!(
    typeof window !== 'undefined' &&
    window.process &&
    (window.process as any).type === 'renderer'
  ) || !!(
    typeof navigator !== 'undefined' &&
    navigator.userAgent &&
    navigator.userAgent.toLowerCase().includes('electron')
  );
};

export const isPWA = (): boolean => {
  // Check if running as PWA
  return window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true;
};

export const isDesktopApp = (): boolean => {
  // Check if running as desktop app (Electron or PWA)
  return isElectron() || isPWA();
};

export const getAppPlatform = (): 'electron' | 'pwa' | 'web' => {
  if (isElectron()) return 'electron';
  if (isPWA()) return 'pwa';
  return 'web';
};
