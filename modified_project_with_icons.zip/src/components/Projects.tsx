import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Calendar, Clock, CheckCircle2, Circle } from 'lucide-react';
import { Progress } from './ui/progress';
import { toast } from 'sonner@2.0.3';

interface Project {
  id: string;
  title: string;
  description: string;
  status: 'planning' | 'in-progress' | 'completed';
  progress: number;
  dueDate: string;
  tasks: number;
  completedTasks: number;
}

export function Projects() {
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      title: 'Album Recording - "Midnight Dreams"',
      description: 'Complete recording and production of 12-track album',
      status: 'in-progress',
      progress: 65,
      dueDate: 'Dec 15, 2025',
      tasks: 12,
      completedTasks: 8
    },
    {
      id: '2',
      title: 'Summer Tour Planning',
      description: 'Organize 20-city summer tour across the country',
      status: 'planning',
      progress: 25,
      dueDate: 'Jun 1, 2026',
      tasks: 15,
      completedTasks: 4
    },
    {
      id: '3',
      title: 'Music Video Production',
      description: 'Create music video for lead single',
      status: 'in-progress',
      progress: 80,
      dueDate: 'Nov 20, 2025',
      tasks: 8,
      completedTasks: 6
    },
  ]);

  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    status: 'planning' as const,
    dueDate: '',
  });

  const addProject = () => {
    if (!newProject.title || !newProject.dueDate) {
      toast.error('Please fill in required fields');
      return;
    }

    const project: Project = {
      id: Date.now().toString(),
      ...newProject,
      progress: 0,
      tasks: 0,
      completedTasks: 0,
    };

    setProjects([...projects, project]);
    setNewProject({ title: '', description: '', status: 'planning', dueDate: '' });
    toast.success('Project created successfully');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planning':
        return 'bg-yellow-100 text-yellow-700';
      case 'in-progress':
        return 'bg-blue-100 text-blue-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Projects</h1>
          <p className="text-gray-600">Manage your music projects and tasks</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Project</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label>Project Title *</Label>
                <Input
                  value={newProject.title}
                  onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                  placeholder="Enter project title"
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={newProject.description}
                  onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                  placeholder="Project description"
                  rows={3}
                />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={newProject.status} onValueChange={(value: any) => setNewProject({ ...newProject, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="planning">Planning</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Due Date *</Label>
                <Input
                  type="date"
                  value={newProject.dueDate}
                  onChange={(e) => setNewProject({ ...newProject, dueDate: e.target.value })}
                />
              </div>
              <Button onClick={addProject} className="w-full">Create Project</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Project Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <Circle className="w-5 h-5 text-yellow-500" />
            <p className="text-gray-600">Planning</p>
          </div>
          <p className="text-3xl">{projects.filter(p => p.status === 'planning').length}</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="w-5 h-5 text-blue-500" />
            <p className="text-gray-600">In Progress</p>
          </div>
          <p className="text-3xl">{projects.filter(p => p.status === 'in-progress').length}</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <p className="text-gray-600">Completed</p>
          </div>
          <p className="text-3xl">{projects.filter(p => p.status === 'completed').length}</p>
        </Card>
      </div>

      {/* Projects List */}
      <div className="space-y-4">
        {projects.map((project) => (
          <Card key={project.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl">{project.title}</h3>
                  <Badge className={getStatusColor(project.status)}>
                    {project.status.replace('-', ' ')}
                  </Badge>
                </div>
                <p className="text-gray-600 mb-4">{project.description}</p>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Progress</span>
                <span className="text-sm">{project.progress}%</span>
              </div>
              <Progress value={project.progress} />
            </div>

            <div className="flex items-center justify-between text-sm text-gray-600">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Due: {project.dueDate}</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{project.completedTasks}/{project.tasks} tasks completed</span>
                </div>
              </div>
              <Button variant="outline" size="sm">View Details</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
