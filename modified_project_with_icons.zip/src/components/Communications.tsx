import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Phone, Mail, MessageSquare, Hash, Send, PhoneCall } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function Communications() {
  const [smsMessage, setSmsMessage] = useState('');
  const [smsRecipient, setSmsRecipient] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');
  const [emailRecipient, setEmailRecipient] = useState('');
  const [callNumber, setCallNumber] = useState('');

  const generatePhoneNumber = () => {
    const areaCode = Math.floor(Math.random() * 900) + 100;
    const prefix = Math.floor(Math.random() * 900) + 100;
    const lineNumber = Math.floor(Math.random() * 9000) + 1000;
    const number = `+1 (${areaCode}) ${prefix}-${lineNumber}`;
    toast.success(`Generated number: ${number}`);
    return number;
  };

  const sendSMS = () => {
    if (!smsRecipient || !smsMessage) {
      toast.error('Please enter recipient and message');
      return;
    }
    toast.success('SMS sent successfully!');
    setSmsMessage('');
    setSmsRecipient('');
  };

  const sendEmail = () => {
    if (!emailRecipient || !emailSubject || !emailBody) {
      toast.error('Please fill in all email fields');
      return;
    }
    toast.success('Email sent successfully!');
    setEmailSubject('');
    setEmailBody('');
    setEmailRecipient('');
  };

  const makeCall = () => {
    if (!callNumber) {
      toast.error('Please enter a phone number');
      return;
    }
    toast.success(`Calling ${callNumber}...`);
  };

  const messageTemplates = [
    { name: 'Meeting Confirmation', text: 'Hi! Just confirming our meeting scheduled for tomorrow. Looking forward to it!' },
    { name: 'Follow Up', text: 'Thanks for the great session! Let me know when you\'re available to continue.' },
    { name: 'Contract Reminder', text: 'Friendly reminder about the contract we discussed. Please review when you get a chance.' },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Communications</h1>
        <p className="text-gray-600">Send messages, emails, and make calls</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="p-6 bg-gradient-to-br from-purple-500 to-purple-700 text-white">
          <MessageSquare className="w-10 h-10 mb-3 opacity-80" />
          <h3 className="text-xl mb-2">Text Messages</h3>
          <p className="text-sm opacity-90">234 sent this month</p>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-orange-500 to-orange-700 text-white">
          <Mail className="w-10 h-10 mb-3 opacity-80" />
          <h3 className="text-xl mb-2">Emails</h3>
          <p className="text-sm opacity-90">156 sent this month</p>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-green-500 to-green-700 text-white">
          <Phone className="w-10 h-10 mb-3 opacity-80" />
          <h3 className="text-xl mb-2">Calls</h3>
          <p className="text-sm opacity-90">89 calls this month</p>
        </Card>
      </div>

      <Tabs defaultValue="sms" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sms">
            <MessageSquare className="w-4 h-4 mr-2" />
            SMS
          </TabsTrigger>
          <TabsTrigger value="email">
            <Mail className="w-4 h-4 mr-2" />
            Email
          </TabsTrigger>
          <TabsTrigger value="call">
            <Phone className="w-4 h-4 mr-2" />
            Call
          </TabsTrigger>
          <TabsTrigger value="numbers">
            <Hash className="w-4 h-4 mr-2" />
            Numbers
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sms">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="p-6 lg:col-span-2">
              <h2 className="text-xl mb-4">Send SMS</h2>
              <div className="space-y-4">
                <div>
                  <Label>Recipient Phone Number</Label>
                  <Input
                    value={smsRecipient}
                    onChange={(e) => setSmsRecipient(e.target.value)}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                <div>
                  <Label>Message</Label>
                  <Textarea
                    value={smsMessage}
                    onChange={(e) => setSmsMessage(e.target.value)}
                    placeholder="Type your message here..."
                    rows={6}
                  />
                  <p className="text-sm text-gray-500 mt-1">{smsMessage.length} characters</p>
                </div>
                <Button onClick={sendSMS} className="w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Send SMS
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="mb-4">Quick Templates</h3>
              <div className="space-y-2">
                {messageTemplates.map((template, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full justify-start text-left h-auto p-3"
                    onClick={() => setSmsMessage(template.text)}
                  >
                    <div>
                      <p className="text-sm">{template.name}</p>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">{template.text}</p>
                    </div>
                  </Button>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="email">
          <Card className="p-6">
            <h2 className="text-xl mb-4">Send Email</h2>
            <div className="space-y-4">
              <div>
                <Label>To</Label>
                <Input
                  type="email"
                  value={emailRecipient}
                  onChange={(e) => setEmailRecipient(e.target.value)}
                  placeholder="recipient@example.com"
                />
              </div>
              <div>
                <Label>Subject</Label>
                <Input
                  value={emailSubject}
                  onChange={(e) => setEmailSubject(e.target.value)}
                  placeholder="Email subject"
                />
              </div>
              <div>
                <Label>Message</Label>
                <Textarea
                  value={emailBody}
                  onChange={(e) => setEmailBody(e.target.value)}
                  placeholder="Type your email message here..."
                  rows={10}
                />
              </div>
              <Button onClick={sendEmail} className="w-full">
                <Send className="w-4 h-4 mr-2" />
                Send Email
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="call">
          <Card className="p-6">
            <h2 className="text-xl mb-4">Make a Call</h2>
            <div className="space-y-4">
              <div>
                <Label>Phone Number</Label>
                <Input
                  value={callNumber}
                  onChange={(e) => setCallNumber(e.target.value)}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
              <Button onClick={makeCall} className="w-full bg-green-600 hover:bg-green-700">
                <PhoneCall className="w-4 h-4 mr-2" />
                Start Call
              </Button>

              <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                <h3 className="mb-3">Recent Calls</h3>
                <div className="space-y-2">
                  {[
                    { name: 'John Smith', number: '+1 (555) 123-4567', time: '2 hours ago', duration: '12:34' },
                    { name: 'Sarah Williams', number: '+1 (555) 234-5678', time: '5 hours ago', duration: '8:21' },
                    { name: 'Mike Johnson', number: '+1 (555) 345-6789', time: '1 day ago', duration: '15:43' },
                  ].map((call, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white rounded border">
                      <div>
                        <p>{call.name}</p>
                        <p className="text-sm text-gray-500">{call.number}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">{call.duration}</p>
                        <p className="text-xs text-gray-500">{call.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="numbers">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h2 className="text-xl mb-4">Generate Phone Number</h2>
              <p className="text-gray-600 mb-6">Generate virtual phone numbers for your music business</p>
              <Button onClick={generatePhoneNumber} className="w-full">
                <Hash className="w-4 h-4 mr-2" />
                Generate New Number
              </Button>
            </Card>

            <Card className="p-6">
              <h3 className="mb-4">Your Numbers</h3>
              <div className="space-y-3">
                {[
                  { number: '+1 (555) 789-0123', label: 'Main Business', active: true },
                  { number: '+1 (555) 890-1234', label: 'Studio Line', active: true },
                  { number: '+1 (555) 901-2345', label: 'Booking Inquiries', active: false },
                ].map((num, index) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-lg flex items-center justify-between">
                    <div>
                      <p>{num.number}</p>
                      <p className="text-sm text-gray-600">{num.label}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded ${
                      num.active ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {num.active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
