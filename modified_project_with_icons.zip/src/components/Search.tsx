import { useState } from 'react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Search as SearchIcon, X, FileText, Users, Calendar, DollarSign, Music } from 'lucide-react';

type SearchCategory = 'all' | 'contacts' | 'bookings' | 'invoices' | 'contracts' | 'files';

interface SearchResult {
  id: string;
  title: string;
  category: SearchCategory;
  description: string;
  metadata?: string;
  icon: any;
}

export function Search() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SearchCategory>('all');

  // Mock search results
  const allResults: SearchResult[] = [
    {
      id: '1',
      title: 'Atlantic Records Recording Agreement',
      category: 'contracts',
      description: '3-album deal with Atlantic Records',
      metadata: 'Signed • $250,000',
      icon: FileText
    },
    {
      id: '2',
      title: 'John Smith',
      category: 'contacts',
      description: 'Producer at Universal Music',
      metadata: 'john.smith@universal.com',
      icon: Users
    },
    {
      id: '3',
      title: 'Live Performance at Blue Note',
      category: 'bookings',
      description: 'Blue Note Jazz Club',
      metadata: 'Nov 15, 2025 • $2,500',
      icon: Calendar
    },
    {
      id: '4',
      title: 'INV-2025-001',
      category: 'invoices',
      description: 'Blue Note Entertainment',
      metadata: 'Sent • $2,750',
      icon: DollarSign
    },
    {
      id: '5',
      title: 'New Album Master.wav',
      category: 'files',
      description: 'Audio Files folder',
      metadata: '125 MB • Nov 10, 2025',
      icon: Music
    },
    {
      id: '6',
      title: 'Sarah Williams',
      category: 'contacts',
      description: 'Artist Manager',
      metadata: 'sarah.williams@mgmt.com',
      icon: Users
    },
    {
      id: '7',
      title: 'Studio Recording Session',
      category: 'bookings',
      description: 'Sunset Studios, Los Angeles',
      metadata: 'Nov 18, 2025 • $1,800',
      icon: Calendar
    },
    {
      id: '8',
      title: 'Publishing Rights Agreement',
      category: 'contracts',
      description: 'Universal Music Publishing',
      metadata: 'Pending • $50,000',
      icon: FileText
    }
  ];

  const filteredResults = allResults.filter(result => {
    const matchesSearch = searchQuery === '' || 
      result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      result.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || result.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const categories: { value: SearchCategory; label: string; count: number }[] = [
    { value: 'all', label: 'All Results', count: allResults.length },
    { value: 'contacts', label: 'Contacts', count: allResults.filter(r => r.category === 'contacts').length },
    { value: 'bookings', label: 'Bookings', count: allResults.filter(r => r.category === 'bookings').length },
    { value: 'invoices', label: 'Invoices', count: allResults.filter(r => r.category === 'invoices').length },
    { value: 'contracts', label: 'Contracts', count: allResults.filter(r => r.category === 'contracts').length },
    { value: 'files', label: 'Files', count: allResults.filter(r => r.category === 'files').length }
  ];

  const getCategoryColor = (category: SearchCategory) => {
    switch (category) {
      case 'contacts': return 'bg-blue-100 text-blue-700';
      case 'bookings': return 'bg-purple-100 text-purple-700';
      case 'invoices': return 'bg-green-100 text-green-700';
      case 'contracts': return 'bg-orange-100 text-orange-700';
      case 'files': return 'bg-pink-100 text-pink-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Search</h1>
        <p className="text-gray-600">Search across all your data</p>
      </div>

      {/* Search Bar */}
      <Card className="p-6 mb-6">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search contacts, bookings, invoices, contracts, files..."
            className="pl-10 pr-10 h-12 text-lg"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </Card>

      {/* Category Filters */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map((category) => (
          <Button
            key={category.value}
            variant={selectedCategory === category.value ? 'default' : 'outline'}
            onClick={() => setSelectedCategory(category.value)}
            className="whitespace-nowrap"
          >
            {category.label}
            <Badge variant="secondary" className="ml-2">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>

      {/* Results */}
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-4">
          <p className="text-gray-600">
            {filteredResults.length} {filteredResults.length === 1 ? 'result' : 'results'} found
          </p>
        </div>

        {filteredResults.length > 0 ? (
          filteredResults.map((result) => {
            const Icon = result.icon;
            return (
              <Card key={result.id} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <Icon className="w-6 h-6 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-lg mb-1">{result.title}</h3>
                        <p className="text-gray-600">{result.description}</p>
                      </div>
                      <Badge className={getCategoryColor(result.category)}>
                        {result.category}
                      </Badge>
                    </div>
                    {result.metadata && (
                      <p className="text-sm text-gray-500 mt-2">{result.metadata}</p>
                    )}
                  </div>
                </div>
              </Card>
            );
          })
        ) : (
          <Card className="p-12 text-center">
            <SearchIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl mb-2">No results found</h3>
            <p className="text-gray-600">
              {searchQuery 
                ? `No results found for "${searchQuery}". Try different keywords.`
                : 'Start typing to search across all your data'
              }
            </p>
          </Card>
        )}
      </div>

      {/* Quick Tips */}
      {searchQuery === '' && (
        <Card className="p-6 mt-6 bg-blue-50 border-blue-200">
          <h3 className="mb-3 flex items-center gap-2">
            <SearchIcon className="w-5 h-5 text-blue-600" />
            Search Tips
          </h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>• Search by name, email, company, or any keyword</li>
            <li>• Use category filters to narrow down results</li>
            <li>• Search works across all sections: contacts, bookings, invoices, contracts, and files</li>
            <li>• Click on any result to view full details</li>
          </ul>
        </Card>
      )}
    </div>
  );
}
