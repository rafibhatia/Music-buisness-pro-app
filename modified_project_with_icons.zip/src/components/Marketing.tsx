import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Megaphone, Plus, TrendingUp, Users, Eye, Share2, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type CampaignStatus = 'draft' | 'scheduled' | 'active' | 'completed' | 'paused';
type CampaignType = 'social-media' | 'email' | 'pr' | 'advertising' | 'other';

interface Campaign {
  id: string;
  name: string;
  type: CampaignType;
  status: CampaignStatus;
  startDate: string;
  endDate: string;
  budget: number;
  reach: number;
  engagement: number;
  description: string;
}

export function Marketing() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([
    {
      id: '1',
      name: 'Album Release Campaign',
      type: 'social-media',
      status: 'active',
      startDate: '2025-11-01',
      endDate: '2025-11-30',
      budget: 5000,
      reach: 45000,
      engagement: 3200,
      description: 'Multi-platform campaign for new album release'
    },
    {
      id: '2',
      name: 'Tour Announcement Email Blast',
      type: 'email',
      status: 'scheduled',
      startDate: '2025-11-15',
      endDate: '2025-11-15',
      budget: 500,
      reach: 12000,
      engagement: 0,
      description: 'Email campaign announcing 2026 tour dates'
    },
    {
      id: '3',
      name: 'Press Release - Label Deal',
      type: 'pr',
      status: 'completed',
      startDate: '2025-10-01',
      endDate: '2025-10-15',
      budget: 2000,
      reach: 25000,
      engagement: 1500,
      description: 'PR campaign for Atlantic Records signing'
    },
    {
      id: '4',
      name: 'Spotify Pre-Save Campaign',
      type: 'advertising',
      status: 'scheduled',
      startDate: '2025-11-20',
      endDate: '2025-11-25',
      budget: 1500,
      reach: 0,
      engagement: 0,
      description: 'Pre-save campaign for upcoming single'
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const handleCreateCampaign = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newCampaign: Campaign = {
      id: Date.now().toString(),
      name: formData.get('name') as string,
      type: formData.get('type') as CampaignType,
      status: 'draft',
      startDate: formData.get('startDate') as string,
      endDate: formData.get('endDate') as string,
      budget: parseFloat(formData.get('budget') as string) || 0,
      reach: 0,
      engagement: 0,
      description: formData.get('description') as string
    };

    setCampaigns([newCampaign, ...campaigns]);
    setIsDialogOpen(false);
    toast.success('Campaign created successfully!');
  };

  const getStatusColor = (status: CampaignStatus) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'scheduled': return 'bg-blue-100 text-blue-700';
      case 'completed': return 'bg-gray-100 text-gray-700';
      case 'paused': return 'bg-yellow-100 text-yellow-700';
      case 'draft': return 'bg-gray-100 text-gray-500';
    }
  };

  const getTypeColor = (type: CampaignType) => {
    switch (type) {
      case 'social-media': return 'bg-purple-100 text-purple-700';
      case 'email': return 'bg-orange-100 text-orange-700';
      case 'pr': return 'bg-blue-100 text-blue-700';
      case 'advertising': return 'bg-pink-100 text-pink-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    return filterStatus === 'all' || campaign.status === filterStatus;
  });

  const stats = {
    totalReach: campaigns.reduce((sum, c) => sum + c.reach, 0),
    totalEngagement: campaigns.reduce((sum, c) => sum + c.engagement, 0),
    activeCampaigns: campaigns.filter(c => c.status === 'active').length,
    totalBudget: campaigns.reduce((sum, c) => sum + c.budget, 0)
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Marketing Campaigns</h1>
          <p className="text-gray-600">Plan and track your marketing initiatives</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Campaign
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Campaign</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateCampaign} className="space-y-4">
              <div>
                <Label>Campaign Name</Label>
                <Input name="name" required placeholder="e.g., Album Release Campaign" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Campaign Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="social-media">Social Media</SelectItem>
                      <SelectItem value="email">Email Marketing</SelectItem>
                      <SelectItem value="pr">Public Relations</SelectItem>
                      <SelectItem value="advertising">Advertising</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Budget ($)</Label>
                  <Input name="budget" type="number" step="0.01" placeholder="0.00" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Start Date</Label>
                  <Input name="startDate" type="date" required />
                </div>
                <div>
                  <Label>End Date</Label>
                  <Input name="endDate" type="date" required />
                </div>
              </div>
              <div>
                <Label>Description</Label>
                <Textarea name="description" rows={3} placeholder="Campaign details and goals..." />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Campaign</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Reach</p>
              <p className="text-3xl">{stats.totalReach.toLocaleString()}</p>
            </div>
            <Eye className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Engagement</p>
              <p className="text-3xl">{stats.totalEngagement.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active</p>
              <p className="text-3xl">{stats.activeCampaigns}</p>
            </div>
            <Megaphone className="w-10 h-10 text-purple-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Budget</p>
              <p className="text-3xl">${stats.totalBudget.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-10 h-10 text-orange-500 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Filter */}
      <Card className="p-4 mb-6">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Campaigns</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="scheduled">Scheduled</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
          </SelectContent>
        </Select>
      </Card>

      {/* Campaigns List */}
      <div className="space-y-4">
        {filteredCampaigns.map((campaign) => (
          <Card key={campaign.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl mb-2">{campaign.name}</h3>
                <p className="text-gray-600">{campaign.description}</p>
              </div>
              <div className="flex gap-2">
                <Badge className={getStatusColor(campaign.status)}>
                  {campaign.status}
                </Badge>
                <Badge className={getTypeColor(campaign.type)}>
                  {campaign.type}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500">Start Date</p>
                <p>{new Date(campaign.startDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">End Date</p>
                <p>{new Date(campaign.endDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Budget</p>
                <p>${campaign.budget.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Reach</p>
                <p>{campaign.reach.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Engagement</p>
                <p>{campaign.engagement.toLocaleString()}</p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                View Details
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-1" />
                Share
              </Button>
              <Button variant="outline" size="sm">
                Edit
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredCampaigns.length === 0 && (
        <Card className="p-12 text-center">
          <Megaphone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No campaigns found</h3>
          <p className="text-gray-600">Try adjusting your filters or create a new campaign</p>
        </Card>
      )}
    </div>
  );
}
