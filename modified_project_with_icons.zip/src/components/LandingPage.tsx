import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Download, Music, Phone, Mail, MessageSquare, BarChart3, FolderOpen, X, Check } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
  onViewGuide: () => void;
}

export function LandingPage({ onGetStarted, onViewGuide }: LandingPageProps) {
  const [isInstalled, setIsInstalled] = useState(false);
  const [canInstall, setCanInstall] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Check if install is available
    const handler = (e: Event) => {
      e.preventDefault();
      setCanInstall(true);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl mb-6 shadow-lg">
            <Music className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl mb-4">Music Business Pro</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Complete business management for music professionals. Manage contacts, communications, projects, and analytics all in one place.
          </p>
        </div>

        {/* Installation Status Banner */}
        {isInstalled ? (
          <Card className="mb-8 p-6 bg-green-50 border-green-200">
            <div className="flex items-center gap-3 text-green-800">
              <Check className="w-6 h-6" />
              <div>
                <h3 className="font-semibold">App Installed Successfully!</h3>
                <p className="text-sm">You're running Music Business Pro as a standalone desktop application.</p>
              </div>
            </div>
          </Card>
        ) : (
          <Card className="mb-8 p-6 bg-blue-50 border-blue-200">
            <div className="flex items-start gap-3">
              <Download className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h3 className="font-semibold text-blue-900 mb-2">Install as Desktop App</h3>
                <p className="text-sm text-blue-800 mb-4">
                  Install Music Business Pro on your computer for the best experience. Works offline, runs without a browser, and gives you quick access from your desktop.
                </p>
                <div className="flex gap-3">
                  {canInstall && (
                    <Button onClick={onGetStarted} className="bg-blue-600 hover:bg-blue-700">
                      <Download className="w-4 h-4 mr-2" />
                      Install Now
                    </Button>
                  )}
                  <Button onClick={onViewGuide} variant="outline">
                    View Installation Guide
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Card className="p-6">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Phone className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="mb-2">Communications Hub</h3>
            <p className="text-sm text-gray-600">
              Manage SMS, emails, and calls all in one place. Track conversations and stay organized.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="mb-2">Contact Management</h3>
            <p className="text-sm text-gray-600">
              Store and organize all your industry contacts with notes, tags, and interaction history.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <FolderOpen className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="mb-2">Project Tracking</h3>
            <p className="text-sm text-gray-600">
              Manage releases, tours, and collaborations with task lists and milestone tracking.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
              <BarChart3 className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="mb-2">Analytics Dashboard</h3>
            <p className="text-sm text-gray-600">
              Track your business metrics, communication stats, and project progress at a glance.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4">
              <Mail className="w-6 h-6 text-pink-600" />
            </div>
            <h3 className="mb-2">Email Integration</h3>
            <p className="text-sm text-gray-600">
              Send and track professional emails with templates and scheduling options.
            </p>
          </Card>

          <Card className="p-6">
            <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
              <Download className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="mb-2">Offline Access</h3>
            <p className="text-sm text-gray-600">
              Once installed, access your data and work even without an internet connection.
            </p>
          </Card>
        </div>

        {/* Benefits Section */}
        <Card className="p-8 mb-8 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
          <h2 className="text-2xl mb-6 text-center">Why Install as a Desktop App?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="mb-2">No Browser UI</h4>
              <p className="text-sm text-gray-600">
                Runs like a native app without browser tabs and toolbars for a cleaner workspace.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="mb-2">Quick Launch</h4>
              <p className="text-sm text-gray-600">
                Access directly from your desktop or taskbar—no need to open a browser first.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="mb-2">Works Offline</h4>
              <p className="text-sm text-gray-600">
                Continue working even without an internet connection—your data syncs when you're back online.
              </p>
            </div>
          </div>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-2xl mb-4">Ready to Get Started?</h2>
          <p className="text-gray-600 mb-6">
            {isInstalled 
              ? "You're all set! Click below to start using Music Business Pro."
              : "Install the app or continue in your browser."}
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button onClick={onGetStarted} size="lg" className="bg-purple-600 hover:bg-purple-700">
              {isInstalled ? 'Open App' : 'Continue to App'}
            </Button>
            {!isInstalled && (
              <Button onClick={onViewGuide} variant="outline" size="lg">
                Installation Guide
              </Button>
            )}
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-12 text-center text-sm text-gray-500">
          <p>Note: For full SMS, calling, and email functionality, backend integration with services like Twilio and SendGrid is required.</p>
        </div>
      </div>
    </div>
  );
}
