import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { User, Bell, Shield, Palette, Database, Download, ExternalLink } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function Settings() {
  const saveSettings = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Settings</h1>
        <p className="text-gray-600">Manage your account and application preferences</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile">
            <User className="w-4 h-4 mr-2" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Palette className="w-4 h-4 mr-2" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="data">
            <Database className="w-4 h-4 mr-2" />
            Data
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card className="p-6">
            <h2 className="text-xl mb-6">Profile Settings</h2>
            <div className="space-y-4 max-w-xl">
              <div>
                <Label>Full Name</Label>
                <Input placeholder="Your name" defaultValue="Music Professional" />
              </div>
              <div>
                <Label>Email</Label>
                <Input type="email" placeholder="your@email.com" defaultValue="music@example.com" />
              </div>
              <div>
                <Label>Business Name</Label>
                <Input placeholder="Your business name" defaultValue="Music Biz Pro Studio" />
              </div>
              <div>
                <Label>Phone Number</Label>
                <Input placeholder="+1 (555) 123-4567" defaultValue="+1 (555) 789-0123" />
              </div>
              <div>
                <Label>Bio</Label>
                <Input placeholder="Tell us about yourself" />
              </div>
              <Button onClick={saveSettings}>Save Changes</Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card className="p-6">
            <h2 className="text-xl mb-6">Notification Preferences</h2>
            <div className="space-y-6 max-w-xl">
              <div className="flex items-center justify-between">
                <div>
                  <p>Email Notifications</p>
                  <p className="text-sm text-gray-600">Receive email updates about your activity</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>SMS Notifications</p>
                  <p className="text-sm text-gray-600">Get text messages for important updates</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>Call Reminders</p>
                  <p className="text-sm text-gray-600">Reminder notifications for scheduled calls</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>Project Updates</p>
                  <p className="text-sm text-gray-600">Notifications when projects are updated</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>New Contact Alerts</p>
                  <p className="text-sm text-gray-600">Get notified when new contacts are added</p>
                </div>
                <Switch />
              </div>
              <Button onClick={saveSettings}>Save Preferences</Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card className="p-6">
            <h2 className="text-xl mb-6">Security Settings</h2>
            <div className="space-y-4 max-w-xl">
              <div>
                <Label>Current Password</Label>
                <Input type="password" placeholder="Enter current password" />
              </div>
              <div>
                <Label>New Password</Label>
                <Input type="password" placeholder="Enter new password" />
              </div>
              <div>
                <Label>Confirm New Password</Label>
                <Input type="password" placeholder="Confirm new password" />
              </div>
              <Button onClick={saveSettings}>Update Password</Button>
              
              <div className="pt-6 mt-6 border-t">
                <h3 className="mb-4">Two-Factor Authentication</h3>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p>Enable 2FA</p>
                    <p className="text-sm text-gray-600">Add an extra layer of security</p>
                  </div>
                  <Switch />
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card className="p-6">
            <h2 className="text-xl mb-6">Appearance Settings</h2>
            <div className="space-y-6 max-w-xl">
              <div className="flex items-center justify-between">
                <div>
                  <p>Dark Mode</p>
                  <p className="text-sm text-gray-600">Switch to dark theme</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>Compact View</p>
                  <p className="text-sm text-gray-600">Show more content on screen</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p>Show Avatars</p>
                  <p className="text-sm text-gray-600">Display contact profile pictures</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Button onClick={saveSettings}>Save Appearance</Button>

              <div className="pt-6 border-t">
                <h3 className="mb-4">Desktop App Installation</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-3">
                      Install Music Business Pro as a desktop application for quick access, offline use, and a native app experience.
                    </p>
                    <Button 
                      variant="outline" 
                      onClick={() => window.location.href = '?view=guide'}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      View Installation Guide
                    </Button>
                  </div>
                  {window.matchMedia('(display-mode: standalone)').matches && (
                    <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 p-3 rounded-lg">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      App is currently installed and running in standalone mode
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card className="p-6">
            <h2 className="text-xl mb-6">Data Management</h2>
            <div className="space-y-6 max-w-xl">
              <div>
                <h3 className="mb-2">Export Data</h3>
                <p className="text-sm text-gray-600 mb-4">Download all your data in JSON format</p>
                <Button variant="outline">Export All Data</Button>
              </div>
              
              <div className="pt-6 border-t">
                <h3 className="mb-2">Import Data</h3>
                <p className="text-sm text-gray-600 mb-4">Import contacts and projects from a file</p>
                <Button variant="outline">Import Data</Button>
              </div>

              <div className="pt-6 border-t">
                <h3 className="mb-2 text-red-600">Danger Zone</h3>
                <p className="text-sm text-gray-600 mb-4">Permanently delete your account and all data</p>
                <Button variant="destructive">Delete Account</Button>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
