import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FileText, FolderOpen, Upload, Download, Trash2, Eye, Music, Image as ImageIcon, File } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type FileType = 'audio' | 'image' | 'document' | 'video' | 'other';

interface FileItem {
  id: string;
  name: string;
  type: FileType;
  size: string;
  uploadDate: string;
  folder: string;
  tags: string[];
}

export function Files() {
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: '1',
      name: 'New Album Master.wav',
      type: 'audio',
      size: '125 MB',
      uploadDate: '2025-11-10',
      folder: 'Audio Files',
      tags: ['album', 'master']
    },
    {
      id: '2',
      name: 'Press Kit 2025.pdf',
      type: 'document',
      size: '2.5 MB',
      uploadDate: '2025-11-08',
      folder: 'Documents',
      tags: ['press', 'marketing']
    },
    {
      id: '3',
      name: 'Album Cover Final.jpg',
      type: 'image',
      size: '8.2 MB',
      uploadDate: '2025-11-05',
      folder: 'Images',
      tags: ['album', 'artwork']
    },
    {
      id: '4',
      name: 'Atlantic Records Contract.pdf',
      type: 'document',
      size: '1.2 MB',
      uploadDate: '2025-10-15',
      folder: 'Contracts',
      tags: ['contract', 'legal']
    },
    {
      id: '5',
      name: 'Live Performance Video.mp4',
      type: 'video',
      size: '450 MB',
      uploadDate: '2025-11-01',
      folder: 'Videos',
      tags: ['live', 'performance']
    }
  ]);

  const [selectedFolder, setSelectedFolder] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');

  const getFileIcon = (type: FileType) => {
    switch (type) {
      case 'audio': return <Music className="w-5 h-5 text-purple-500" />;
      case 'image': return <ImageIcon className="w-5 h-5 text-blue-500" />;
      case 'video': return <File className="w-5 h-5 text-red-500" />;
      case 'document': return <FileText className="w-5 h-5 text-orange-500" />;
      default: return <File className="w-5 h-5 text-gray-500" />;
    }
  };

  const getTypeColor = (type: FileType) => {
    switch (type) {
      case 'audio': return 'bg-purple-100 text-purple-700';
      case 'image': return 'bg-blue-100 text-blue-700';
      case 'video': return 'bg-red-100 text-red-700';
      case 'document': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const filteredFiles = files.filter(file => {
    const folderMatch = selectedFolder === 'all' || file.folder === selectedFolder;
    const typeMatch = selectedType === 'all' || file.type === selectedType;
    return folderMatch && typeMatch;
  });

  const folders = Array.from(new Set(files.map(f => f.folder)));
  
  const stats = {
    total: files.length,
    audio: files.filter(f => f.type === 'audio').length,
    documents: files.filter(f => f.type === 'document').length,
    images: files.filter(f => f.type === 'image').length
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">File Management</h1>
          <p className="text-gray-600">Upload, organize, and manage your files</p>
        </div>
        <Button>
          <Upload className="w-4 h-4 mr-2" />
          Upload Files
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Files</p>
              <p className="text-3xl">{stats.total}</p>
            </div>
            <File className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Audio Files</p>
              <p className="text-3xl">{stats.audio}</p>
            </div>
            <Music className="w-10 h-10 text-purple-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Documents</p>
              <p className="text-3xl">{stats.documents}</p>
            </div>
            <FileText className="w-10 h-10 text-orange-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Images</p>
              <p className="text-3xl">{stats.images}</p>
            </div>
            <ImageIcon className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar - Folders */}
        <div>
          <Card className="p-4">
            <h3 className="mb-4 flex items-center gap-2">
              <FolderOpen className="w-5 h-5" />
              Folders
            </h3>
            <div className="space-y-2">
              <Button
                variant={selectedFolder === 'all' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setSelectedFolder('all')}
              >
                All Files
              </Button>
              {folders.map(folder => (
                <Button
                  key={folder}
                  variant={selectedFolder === folder ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setSelectedFolder(folder)}
                >
                  <FolderOpen className="w-4 h-4 mr-2" />
                  {folder}
                </Button>
              ))}
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          {/* Filter */}
          <Card className="p-4">
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="audio">Audio</SelectItem>
                <SelectItem value="image">Images</SelectItem>
                <SelectItem value="video">Videos</SelectItem>
                <SelectItem value="document">Documents</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </Card>

          {/* Files Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredFiles.map((file) => (
              <Card key={file.id} className="p-4 hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-3 mb-3">
                  <div className="p-2 bg-gray-50 rounded-lg">
                    {getFileIcon(file.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="truncate">{file.name}</h3>
                    <p className="text-sm text-gray-500">{file.size}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <Badge className={getTypeColor(file.type)} variant="secondary">
                    {file.type}
                  </Badge>
                  {file.tags.map(tag => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <p className="text-xs text-gray-500 mb-3">
                  Uploaded {new Date(file.uploadDate).toLocaleDateString()}
                </p>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                  <Button variant="outline" size="sm">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredFiles.length === 0 && (
            <Card className="p-12 text-center">
              <File className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl mb-2">No files found</h3>
              <p className="text-gray-600">Try adjusting your filters or upload new files</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
