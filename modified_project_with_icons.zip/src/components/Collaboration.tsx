import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Users, MessageSquare, FileText, Plus, Send } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Note {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  project: string;
}

interface TeamMember {
  id: string;
  name: string;
  role: string;
  initials: string;
  status: 'online' | 'offline' | 'away';
}

export function Collaboration() {
  const [notes, setNotes] = useState<Note[]>([
    {
      id: '1',
      author: 'You',
      content: 'Need to finalize the album artwork by Friday. Designer is working on final revisions.',
      timestamp: '2025-11-12 10:30 AM',
      project: 'New Album'
    },
    {
      id: '2',
      author: 'Sarah (Manager)',
      content: 'Got confirmation from the venue. Soundcheck is at 6 PM sharp. Make sure everyone arrives on time.',
      timestamp: '2025-11-12 09:15 AM',
      project: 'Blue Note Gig'
    },
    {
      id: '3',
      author: 'Mike (Producer)',
      content: 'Studio session went great! Tracks 3-5 are ready for mixing. Sending stems over tonight.',
      timestamp: '2025-11-11 08:45 PM',
      project: 'Recording Session'
    }
  ]);

  const [newNote, setNewNote] = useState('');

  const teamMembers: TeamMember[] = [
    { id: '1', name: 'Sarah Williams', role: 'Manager', initials: 'SW', status: 'online' },
    { id: '2', name: 'Mike Johnson', role: 'Producer', initials: 'MJ', status: 'online' },
    { id: '3', name: 'Alex Chen', role: 'Sound Engineer', initials: 'AC', status: 'away' },
    { id: '4', name: 'Emma Davis', role: 'Designer', initials: 'ED', status: 'offline' },
    { id: '5', name: 'Chris Taylor', role: 'Publicist', initials: 'CT', status: 'online' }
  ];

  const sharedProjects = [
    { name: 'New Album Release', members: 4, updates: 12, status: 'active' },
    { name: '2026 Tour Planning', members: 3, updates: 8, status: 'active' },
    { name: 'Marketing Campaign', members: 2, updates: 5, status: 'pending' }
  ];

  const handleAddNote = () => {
    if (!newNote.trim()) {
      toast.error('Please enter a note');
      return;
    }

    const note: Note = {
      id: Date.now().toString(),
      author: 'You',
      content: newNote,
      timestamp: new Date().toLocaleString(),
      project: 'General'
    };

    setNotes([note, ...notes]);
    setNewNote('');
    toast.success('Note added successfully!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-400';
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Team Collaboration</h1>
        <p className="text-gray-600">Work together with your team and share updates</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Add New Note */}
          <Card className="p-6">
            <h2 className="text-xl mb-4 flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Shared Notes
            </h2>
            <div className="space-y-4">
              <div className="flex gap-3">
                <Textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Share an update with your team..."
                  rows={3}
                  className="flex-1"
                />
              </div>
              <Button onClick={handleAddNote} className="w-full">
                <Send className="w-4 h-4 mr-2" />
                Post Note
              </Button>
            </div>
          </Card>

          {/* Notes Feed */}
          <div className="space-y-4">
            {notes.map((note) => (
              <Card key={note.id} className="p-6">
                <div className="flex gap-4">
                  <Avatar>
                    <AvatarFallback className="bg-purple-100 text-purple-700">
                      {note.author[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p>{note.author}</p>
                        <p className="text-sm text-gray-500">{note.timestamp}</p>
                      </div>
                      <Badge variant="outline">{note.project}</Badge>
                    </div>
                    <p className="text-gray-700">{note.content}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Shared Projects */}
          <Card className="p-6">
            <h2 className="text-xl mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Shared Projects
            </h2>
            <div className="space-y-3">
              {sharedProjects.map((project, index) => (
                <div key={index} className="p-4 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="mb-1">{project.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>{project.members} members</span>
                        <span>•</span>
                        <span>{project.updates} updates</span>
                      </div>
                    </div>
                    <Badge className={project.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                      {project.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Team Members */}
          <Card className="p-6">
            <h2 className="text-xl mb-4 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Team Members
            </h2>
            <div className="space-y-3">
              {teamMembers.map((member) => (
                <div key={member.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="relative">
                    <Avatar>
                      <AvatarFallback className="bg-blue-100 text-blue-700">
                        {member.initials}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(member.status)}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm">{member.name}</p>
                    <p className="text-xs text-gray-500">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Invite Member
            </Button>
          </Card>

          {/* Activity Summary */}
          <Card className="p-6">
            <h3 className="mb-4">Activity Summary</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Today's Updates</span>
                <Badge>15</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Active Projects</span>
                <Badge>2</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Team Members</span>
                <Badge>{teamMembers.length}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Online Now</span>
                <Badge className="bg-green-100 text-green-700">
                  {teamMembers.filter(m => m.status === 'online').length}
                </Badge>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
