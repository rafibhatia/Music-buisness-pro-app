import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, UserPlus, Phone, Mail, MessageSquare, MoreVertical } from 'lucide-react';
import { Avatar, AvatarFallback } from './ui/avatar';
import { toast } from 'sonner@2.0.3';

interface Contact {
  id: string;
  name: string;
  role: string;
  phone: string;
  email: string;
  category: string;
}

export function Contacts() {
  const [searchQuery, setSearchQuery] = useState('');
  const [contacts, setContacts] = useState<Contact[]>([
    { id: '1', name: 'John Smith', role: 'Producer', phone: '+1 (555) 123-4567', email: 'john@example.com', category: 'collaborator' },
    { id: '2', name: 'Sarah Williams', role: 'Manager', phone: '+1 (555) 234-5678', email: 'sarah@example.com', category: 'team' },
    { id: '3', name: 'Mike Johnson', role: 'Sound Engineer', phone: '+1 (555) 345-6789', email: 'mike@example.com', category: 'collaborator' },
    { id: '4', name: 'Emily Davis', role: 'Label Executive', phone: '+1 (555) 456-7890', email: 'emily@example.com', category: 'business' },
    { id: '5', name: 'David Brown', role: 'Marketing Director', phone: '+1 (555) 567-8901', email: 'david@example.com', category: 'business' },
  ]);

  const [newContact, setNewContact] = useState({
    name: '',
    role: '',
    phone: '',
    email: '',
    category: 'collaborator'
  });

  const addContact = () => {
    if (!newContact.name || !newContact.phone || !newContact.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    const contact: Contact = {
      id: Date.now().toString(),
      ...newContact
    };

    setContacts([...contacts, contact]);
    setNewContact({ name: '', role: '', phone: '', email: '', category: 'collaborator' });
    toast.success('Contact added successfully');
  };

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Contacts</h1>
          <p className="text-gray-600">Manage your music industry contacts</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              Add Contact
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Contact</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label>Name *</Label>
                <Input
                  value={newContact.name}
                  onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                  placeholder="Enter name"
                />
              </div>
              <div>
                <Label>Role</Label>
                <Input
                  value={newContact.role}
                  onChange={(e) => setNewContact({ ...newContact, role: e.target.value })}
                  placeholder="e.g. Producer, Manager"
                />
              </div>
              <div>
                <Label>Phone *</Label>
                <Input
                  value={newContact.phone}
                  onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                  placeholder="+1 (555) 123-4567"
                />
              </div>
              <div>
                <Label>Email *</Label>
                <Input
                  type="email"
                  value={newContact.email}
                  onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                  placeholder="email@example.com"
                />
              </div>
              <div>
                <Label>Category</Label>
                <Select value={newContact.category} onValueChange={(value) => setNewContact({ ...newContact, category: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="collaborator">Collaborator</SelectItem>
                    <SelectItem value="team">Team</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="fan">Fan</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={addContact} className="w-full">Add Contact</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search contacts..."
            className="pl-10"
          />
        </div>
      </div>

      {/* Contacts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredContacts.map((contact) => (
          <Card key={contact.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-purple-100 text-purple-700">
                    {getInitials(contact.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="mb-1">{contact.name}</h3>
                  <p className="text-sm text-gray-600">{contact.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="w-4 h-4" />
                {contact.phone}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                {contact.email}
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => toast.success('Calling ' + contact.name)}>
                <Phone className="w-3 h-3 mr-1" />
                Call
              </Button>
              <Button variant="outline" size="sm" className="flex-1" onClick={() => toast.success('Messaging ' + contact.name)}>
                <MessageSquare className="w-3 h-3 mr-1" />
                Text
              </Button>
              <Button variant="outline" size="sm" className="flex-1" onClick={() => toast.success('Emailing ' + contact.name)}>
                <Mail className="w-3 h-3 mr-1" />
                Email
              </Button>
            </div>

            <div className="mt-3">
              <span className={`inline-block text-xs px-2 py-1 rounded ${
                contact.category === 'team' ? 'bg-blue-100 text-blue-700' :
                contact.category === 'collaborator' ? 'bg-green-100 text-green-700' :
                contact.category === 'business' ? 'bg-purple-100 text-purple-700' :
                'bg-gray-100 text-gray-700'
              }`}>
                {contact.category}
              </span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
