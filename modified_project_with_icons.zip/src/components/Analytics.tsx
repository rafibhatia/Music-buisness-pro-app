import { Card } from './ui/card';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export function Analytics() {
  const monthlyData = [
    { month: 'Jun', calls: 65, emails: 120, sms: 89 },
    { month: 'Jul', calls: 78, emails: 145, sms: 102 },
    { month: 'Aug', calls: 92, emails: 168, sms: 134 },
    { month: 'Sep', calls: 88, emails: 152, sms: 121 },
    { month: 'Oct', calls: 95, emails: 178, sms: 145 },
    { month: 'Nov', calls: 89, emails: 156, sms: 123 },
  ];

  const contactTypeData = [
    { name: 'Collaborators', value: 98, color: '#10b981' },
    { name: 'Team', value: 65, color: '#3b82f6' },
    { name: 'Business', value: 54, color: '#8b5cf6' },
    { name: 'Fans', value: 30, color: '#f59e0b' },
  ];

  const projectStatusData = [
    { status: 'Planning', count: 5 },
    { status: 'In Progress', count: 8 },
    { status: 'Completed', count: 12 },
    { status: 'On Hold', count: 3 },
  ];

  const stats = [
    { label: 'Total Communications', value: '1,779', change: '+12.5%', trending: 'up' },
    { label: 'Active Projects', value: '13', change: '+3', trending: 'up' },
    { label: 'New Contacts', value: '47', change: '-5.2%', trending: 'down' },
    { label: 'Response Rate', value: '94%', change: '+2.1%', trending: 'up' },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Analytics</h1>
        <p className="text-gray-600">Track your music business performance</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <Card key={index} className="p-6">
            <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
            <div className="flex items-end justify-between">
              <p className="text-3xl">{stat.value}</p>
              <div className={`flex items-center gap-1 text-sm ${
                stat.trending === 'up' ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.trending === 'up' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                {stat.change}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Communications Over Time */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-purple-500" />
            <h2 className="text-xl">Communications Activity</h2>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calls" stroke="#8b5cf6" strokeWidth={2} />
              <Line type="monotone" dataKey="emails" stroke="#f59e0b" strokeWidth={2} />
              <Line type="monotone" dataKey="sms" stroke="#10b981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Contact Distribution */}
        <Card className="p-6">
          <h2 className="text-xl mb-4">Contact Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={contactTypeData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {contactTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Project Status */}
      <Card className="p-6">
        <h2 className="text-xl mb-4">Project Status Overview</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={projectStatusData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="status" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#8b5cf6" />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
