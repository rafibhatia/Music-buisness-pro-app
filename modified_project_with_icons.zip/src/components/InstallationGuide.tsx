import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { ArrowLeft, Chrome, Download, Info, Menu, MoreVertical, Share, Monitor, Smartphone } from 'lucide-react';

interface InstallationGuideProps {
  onBack: () => void;
  onGetStarted: () => void;
}

export function InstallationGuide({ onBack, onGetStarted }: InstallationGuideProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8">
          <Button onClick={onBack} variant="ghost" className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <h1 className="text-3xl mb-2">Installation Guide</h1>
          <p className="text-gray-600">
            Follow these step-by-step instructions to install Music Business Pro as a desktop application on your computer.
          </p>
        </div>

        {/* Platform Tabs */}
        <Tabs defaultValue="windows" className="mb-8">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="windows">
              <Monitor className="w-4 h-4 mr-2" />
              Windows
            </TabsTrigger>
            <TabsTrigger value="mac">
              <Monitor className="w-4 h-4 mr-2" />
              Mac
            </TabsTrigger>
          </TabsList>

          {/* Windows Instructions */}
          <TabsContent value="windows">
            <Card className="p-6 mb-6">
              <h2 className="text-xl mb-4">Installing on Windows</h2>
              
              {/* Chrome */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Chrome className="w-5 h-5 text-blue-600" />
                  <h3>Google Chrome / Microsoft Edge</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Open Music Business Pro in Chrome or Edge browser.</p>
                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertDescription>
                          You should see an install icon (computer with download arrow) in the address bar on the right side.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Click the install icon in the address bar, OR click the three-dot menu (⋮) and select "Install Music Business Pro..."</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Click "Install" in the popup dialog.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      4
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">The app will open in its own window. You'll find it:</p>
                      <ul className="list-disc list-inside ml-4 text-sm text-gray-600 space-y-1">
                        <li>On your Desktop (if you checked that option)</li>
                        <li>In your Start Menu</li>
                        <li>Pinnable to your Taskbar (right-click the app and select "Pin to taskbar")</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Alternative Method */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="mb-2">Alternative Method:</h4>
                <p className="text-sm text-gray-600">
                  If you don't see the install icon, look for a notification banner at the bottom or top of the page with an "Install" button.
                </p>
              </div>
            </Card>
          </TabsContent>

          {/* Mac Instructions */}
          <TabsContent value="mac">
            <Card className="p-6 mb-6">
              <h2 className="text-xl mb-4">Installing on Mac</h2>
              
              {/* Chrome */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Chrome className="w-5 h-5 text-blue-600" />
                  <h3>Google Chrome</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Open Music Business Pro in Chrome browser.</p>
                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertDescription>
                          Look for an install icon (computer with download arrow) in the address bar.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Click the install icon, OR click the three-dot menu (⋮) and select "Install Music Business Pro..."</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Click "Install" in the popup dialog.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      4
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">The app will open in its own window and be added to your Applications folder. You can:</p>
                      <ul className="list-disc list-inside ml-4 text-sm text-gray-600 space-y-1">
                        <li>Find it in Applications</li>
                        <li>Add it to your Dock (drag from Applications to Dock)</li>
                        <li>Open it with Spotlight (⌘ + Space, then type "Music Business Pro")</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Safari */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Share className="w-5 h-5 text-blue-600" />
                  <h3>Safari</h3>
                </div>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      1
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Open Music Business Pro in Safari.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      2
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Click the Share button in the Safari toolbar (square with arrow pointing up).</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      3
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">Select "Add to Dock" from the menu.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center">
                      4
                    </div>
                    <div className="flex-1">
                      <p className="mb-2">The app icon will appear in your Dock. Click it to open the app in standalone mode.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Alternative Method */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="mb-2">Note:</h4>
                <p className="text-sm text-gray-600">
                  For the best experience on Mac, we recommend using Chrome or Edge browser for installation.
                </p>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Browser Support */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl mb-4">Browser Compatibility</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                ✓
              </div>
              <div>
                <h4 className="text-green-800">Fully Supported</h4>
                <p className="text-sm text-gray-600">Chrome, Edge, Opera, Brave</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                ✓
              </div>
              <div>
                <h4 className="text-blue-800">Supported (Limited)</h4>
                <p className="text-sm text-gray-600">Safari (Mac/iOS), Firefox</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Troubleshooting */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl mb-4">Troubleshooting</h2>
          <div className="space-y-4">
            <div>
              <h4 className="mb-2">Don't see the install option?</h4>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                <li>Make sure you're using a supported browser (Chrome, Edge, etc.)</li>
                <li>Try refreshing the page</li>
                <li>Check that you're accessing the app via HTTPS (secure connection)</li>
                <li>Look for a notification banner at the top or bottom of the page</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-2">Already installed but can't find it?</h4>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                <li>Windows: Check Start Menu, Desktop, or search for "Music Business Pro"</li>
                <li>Mac: Check Applications folder or use Spotlight search</li>
                <li>You can also access it through your browser's app menu (chrome://apps in Chrome)</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-2">Want to uninstall?</h4>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 ml-4">
                <li>Windows: Right-click the app and select "Uninstall"</li>
                <li>Mac: Move the app from Applications to Trash</li>
                <li>Or use the browser's settings to manage installed web apps</li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Benefits Reminder */}
        <Card className="p-6 mb-8 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
          <h2 className="text-xl mb-4">Why Install?</h2>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mb-2 shadow-sm">
                <Download className="w-5 h-5 text-purple-600" />
              </div>
              <h4 className="mb-1">Quick Access</h4>
              <p className="text-gray-600">Launch directly from desktop or taskbar</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mb-2 shadow-sm">
                <Monitor className="w-5 h-5 text-blue-600" />
              </div>
              <h4 className="mb-1">Native Experience</h4>
              <p className="text-gray-600">Runs like a desktop app without browser UI</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center mb-2 shadow-sm">
                <Smartphone className="w-5 h-5 text-green-600" />
              </div>
              <h4 className="mb-1">Offline Ready</h4>
              <p className="text-gray-600">Works even without internet connection</p>
            </div>
          </div>
        </Card>

        {/* CTA */}
        <div className="text-center">
          <Button onClick={onGetStarted} size="lg" className="bg-purple-600 hover:bg-purple-700">
            Get Started with Music Business Pro
          </Button>
        </div>
      </div>
    </div>
  );
}
