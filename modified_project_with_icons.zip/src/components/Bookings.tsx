import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Calendar as CalendarIcon, MapPin, DollarSign, Clock, Plus, Music, Mic2, Users, Building } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type BookingStatus = 'pending' | 'confirmed' | 'completed' | 'cancelled';
type BookingType = 'gig' | 'studio' | 'meeting' | 'rehearsal';

interface Booking {
  id: string;
  title: string;
  type: BookingType;
  date: string;
  time: string;
  duration: string;
  venue: string;
  location: string;
  client: string;
  status: BookingStatus;
  payment: number;
  paymentStatus: 'unpaid' | 'deposit' | 'paid';
  notes: string;
}

export function Bookings() {
  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: '1',
      title: 'Live Performance at Blue Note',
      type: 'gig',
      date: '2025-11-15',
      time: '20:00',
      duration: '3 hours',
      venue: 'Blue Note Jazz Club',
      location: 'New York, NY',
      client: 'Blue Note Entertainment',
      status: 'confirmed',
      payment: 2500,
      paymentStatus: 'deposit',
      notes: 'Bring full band setup, soundcheck at 6 PM'
    },
    {
      id: '2',
      title: 'Studio Recording Session',
      type: 'studio',
      date: '2025-11-18',
      time: '10:00',
      duration: '6 hours',
      venue: 'Sunset Studios',
      location: 'Los Angeles, CA',
      client: 'Atlantic Records',
      status: 'confirmed',
      payment: 1800,
      paymentStatus: 'paid',
      notes: 'Recording new album tracks 3-5'
    },
    {
      id: '3',
      title: 'Label Meeting',
      type: 'meeting',
      date: '2025-11-12',
      time: '14:00',
      duration: '2 hours',
      venue: 'Universal Music Office',
      location: 'Nashville, TN',
      client: 'Universal Music Group',
      status: 'pending',
      payment: 0,
      paymentStatus: 'unpaid',
      notes: 'Discuss contract renewal and tour plans'
    },
    {
      id: '4',
      title: 'Band Rehearsal',
      type: 'rehearsal',
      date: '2025-11-13',
      time: '18:00',
      duration: '4 hours',
      venue: 'Main Street Rehearsal Space',
      location: 'Austin, TX',
      client: 'Self',
      status: 'confirmed',
      payment: 200,
      paymentStatus: 'paid',
      notes: 'Prepare for upcoming gig'
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');

  const handleCreateBooking = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newBooking: Booking = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      type: formData.get('type') as BookingType,
      date: formData.get('date') as string,
      time: formData.get('time') as string,
      duration: formData.get('duration') as string,
      venue: formData.get('venue') as string,
      location: formData.get('location') as string,
      client: formData.get('client') as string,
      status: 'pending',
      payment: parseFloat(formData.get('payment') as string) || 0,
      paymentStatus: 'unpaid',
      notes: formData.get('notes') as string
    };

    setBookings([newBooking, ...bookings]);
    setIsDialogOpen(false);
    toast.success('Booking created successfully!');
  };

  const getStatusColor = (status: BookingStatus) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'completed': return 'bg-blue-100 text-blue-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
    }
  };

  const getTypeIcon = (type: BookingType) => {
    switch (type) {
      case 'gig': return <Music className="w-5 h-5" />;
      case 'studio': return <Mic2 className="w-5 h-5" />;
      case 'meeting': return <Users className="w-5 h-5" />;
      case 'rehearsal': return <Building className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: BookingType) => {
    switch (type) {
      case 'gig': return 'bg-purple-100 text-purple-700';
      case 'studio': return 'bg-orange-100 text-orange-700';
      case 'meeting': return 'bg-blue-100 text-blue-700';
      case 'rehearsal': return 'bg-green-100 text-green-700';
    }
  };

  const filteredBookings = bookings.filter(booking => {
    const statusMatch = filterStatus === 'all' || booking.status === filterStatus;
    const typeMatch = filterType === 'all' || booking.type === filterType;
    return statusMatch && typeMatch;
  });

  const stats = {
    total: bookings.length,
    confirmed: bookings.filter(b => b.status === 'confirmed').length,
    pending: bookings.filter(b => b.status === 'pending').length,
    revenue: bookings.reduce((sum, b) => sum + b.payment, 0)
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Booking Management</h1>
          <p className="text-gray-600">Manage gigs, studio sessions, meetings, and rehearsals</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Booking
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Booking</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateBooking} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label>Booking Title</Label>
                  <Input name="title" required placeholder="e.g., Live Performance at Blue Note" />
                </div>
                <div>
                  <Label>Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gig">Gig/Performance</SelectItem>
                      <SelectItem value="studio">Studio Session</SelectItem>
                      <SelectItem value="meeting">Meeting</SelectItem>
                      <SelectItem value="rehearsal">Rehearsal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Client/Contact</Label>
                  <Input name="client" required placeholder="Client or contact name" />
                </div>
                <div>
                  <Label>Date</Label>
                  <Input name="date" type="date" required />
                </div>
                <div>
                  <Label>Time</Label>
                  <Input name="time" type="time" required />
                </div>
                <div>
                  <Label>Duration</Label>
                  <Input name="duration" required placeholder="e.g., 3 hours" />
                </div>
                <div>
                  <Label>Payment Amount ($)</Label>
                  <Input name="payment" type="number" step="0.01" placeholder="0.00" />
                </div>
                <div className="col-span-2">
                  <Label>Venue Name</Label>
                  <Input name="venue" required placeholder="e.g., Blue Note Jazz Club" />
                </div>
                <div className="col-span-2">
                  <Label>Location</Label>
                  <Input name="location" required placeholder="City, State" />
                </div>
                <div className="col-span-2">
                  <Label>Notes</Label>
                  <Textarea name="notes" rows={3} placeholder="Additional details, requirements, etc." />
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Booking</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Bookings</p>
              <p className="text-3xl">{stats.total}</p>
            </div>
            <CalendarIcon className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Confirmed</p>
              <p className="text-3xl">{stats.confirmed}</p>
            </div>
            <Music className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Pending</p>
              <p className="text-3xl">{stats.pending}</p>
            </div>
            <Clock className="w-10 h-10 text-yellow-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
              <p className="text-3xl">${stats.revenue.toLocaleString()}</p>
            </div>
            <DollarSign className="w-10 h-10 text-purple-500 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-4 mb-6">
        <div className="flex gap-4">
          <div className="flex-1">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="confirmed">Confirmed</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="gig">Gigs</SelectItem>
                <SelectItem value="studio">Studio</SelectItem>
                <SelectItem value="meeting">Meetings</SelectItem>
                <SelectItem value="rehearsal">Rehearsals</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Bookings List */}
      <div className="space-y-4">
        {filteredBookings.map((booking) => (
          <Card key={booking.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-2 rounded-lg ${getTypeColor(booking.type)}`}>
                    {getTypeIcon(booking.type)}
                  </div>
                  <div>
                    <h3 className="text-xl">{booking.title}</h3>
                    <p className="text-sm text-gray-600">{booking.client}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                  <div className="flex items-center gap-2 text-sm">
                    <CalendarIcon className="w-4 h-4 text-gray-400" />
                    <span>{new Date(booking.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-gray-400" />
                    <span>{booking.time} ({booking.duration})</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    <span>{booking.venue}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <DollarSign className="w-4 h-4 text-gray-400" />
                    <span>${booking.payment.toLocaleString()}</span>
                  </div>
                </div>

                {booking.notes && (
                  <p className="text-sm text-gray-600 mb-3">{booking.notes}</p>
                )}

                <div className="flex gap-2">
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status}
                  </Badge>
                  <Badge variant="outline">
                    {booking.paymentStatus === 'paid' ? 'Paid' : 
                     booking.paymentStatus === 'deposit' ? 'Deposit Paid' : 'Unpaid'}
                  </Badge>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">Edit</Button>
                <Button variant="outline" size="sm">View</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {filteredBookings.length === 0 && (
        <Card className="p-12 text-center">
          <CalendarIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No bookings found</h3>
          <p className="text-gray-600">Try adjusting your filters or create a new booking</p>
        </Card>
      )}
    </div>
  );
}
