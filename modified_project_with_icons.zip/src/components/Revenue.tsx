import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DollarSign, TrendingUp, Music, Headphones, Radio, Download } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export function Revenue() {
  const monthlyData = [
    { month: 'Jun', streaming: 4200, performances: 8500, royalties: 2100, merchandise: 1200 },
    { month: 'Jul', streaming: 4800, performances: 12000, royalties: 2400, merchandise: 1800 },
    { month: 'Aug', streaming: 5200, performances: 15000, royalties: 2800, merchandise: 2200 },
    { month: 'Sep', streaming: 6100, performances: 10000, royalties: 3200, merchandise: 1900 },
    { month: 'Oct', streaming: 7500, performances: 18000, royalties: 3800, merchandise: 2500 },
    { month: 'Nov', streaming: 8200, performances: 22000, royalties: 4200, merchandise: 3100 }
  ];

  const revenueBySource = [
    { name: 'Live Performances', value: 85500, color: '#8b5cf6' },
    { name: 'Streaming Royalties', value: 36000, color: '#3b82f6' },
    { name: 'Publishing Rights', value: 18500, color: '#10b981' },
    { name: 'Merchandise', value: 12700, color: '#f59e0b' },
    { name: 'Licensing', value: 8300, color: '#ec4899' }
  ];

  const recentTransactions = [
    { id: '1', source: 'Spotify', type: 'Streaming', amount: 1250, date: '2025-11-10', status: 'completed' },
    { id: '2', source: 'Blue Note Gig', type: 'Performance', amount: 2500, date: '2025-11-08', status: 'completed' },
    { id: '3', source: 'Apple Music', type: 'Streaming', amount: 890, date: '2025-11-05', status: 'completed' },
    { id: '4', source: 'ASCAP Royalties', type: 'Publishing', amount: 3200, date: '2025-11-01', status: 'pending' }
  ];

  const totalRevenue = revenueBySource.reduce((sum, item) => sum + item.value, 0);
  const monthlyGrowth = ((monthlyData[5].streaming + monthlyData[5].performances + monthlyData[5].royalties + monthlyData[5].merchandise) - 
                         (monthlyData[4].streaming + monthlyData[4].performances + monthlyData[4].royalties + monthlyData[4].merchandise)) / 
                         (monthlyData[4].streaming + monthlyData[4].performances + monthlyData[4].royalties + monthlyData[4].merchandise) * 100;

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Revenue & Royalty Tracking</h1>
          <p className="text-gray-600">Monitor your income streams and royalties</p>
        </div>
        <div className="flex gap-2">
          <Select defaultValue="2025">
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
              <p className="text-3xl">${totalRevenue.toLocaleString()}</p>
            </div>
            <DollarSign className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Monthly Growth</p>
              <p className="text-3xl">{monthlyGrowth.toFixed(1)}%</p>
            </div>
            <TrendingUp className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Streaming</p>
              <p className="text-3xl">${monthlyData[5].streaming.toLocaleString()}</p>
            </div>
            <Headphones className="w-10 h-10 text-purple-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Performances</p>
              <p className="text-3xl">${monthlyData[5].performances.toLocaleString()}</p>
            </div>
            <Music className="w-10 h-10 text-orange-500 opacity-50" />
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Monthly Revenue Trend */}
        <Card className="p-6">
          <h2 className="text-xl mb-4">Monthly Revenue Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="streaming" stroke="#8b5cf6" strokeWidth={2} />
              <Line type="monotone" dataKey="performances" stroke="#3b82f6" strokeWidth={2} />
              <Line type="monotone" dataKey="royalties" stroke="#10b981" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Revenue by Source */}
        <Card className="p-6">
          <h2 className="text-xl mb-4">Revenue by Source</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={revenueBySource}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.name}: $${(entry.value / 1000).toFixed(0)}k`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {revenueBySource.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Revenue Breakdown */}
      <Card className="p-6 mb-6">
        <h2 className="text-xl mb-4">Revenue Breakdown (Last 6 Months)</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="streaming" stackId="a" fill="#8b5cf6" />
            <Bar dataKey="performances" stackId="a" fill="#3b82f6" />
            <Bar dataKey="royalties" stackId="a" fill="#10b981" />
            <Bar dataKey="merchandise" stackId="a" fill="#f59e0b" />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Recent Transactions */}
      <Card className="p-6">
        <h2 className="text-xl mb-4">Recent Transactions</h2>
        <div className="space-y-3">
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-4 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p>{transaction.source}</p>
                  <p className="text-sm text-gray-500">{transaction.type}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg">${transaction.amount.toLocaleString()}</p>
                <p className="text-sm text-gray-500">{new Date(transaction.date).toLocaleDateString()}</p>
              </div>
              <Badge className={transaction.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                {transaction.status}
              </Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
