import { 
  LayoutDashboard, 
  Users, 
  MessageSquare, 
  FolderKanban, 
  BarChart3, 
  Settings, 
  Music,
  Calendar,
  CalendarCheck,
  CheckSquare,
  FileText,
  FolderOpen,
  Megaphone,
  DollarSign,
  Users2,
  Search,
  UserCircle
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const menuSections = [
    {
      title: 'Main',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'search', label: 'Search', icon: Search },
      ]
    },
    {
      title: 'Business',
      items: [
        { id: 'bookings', label: 'Bookings', icon: CalendarCheck },
        { id: 'calendar', label: 'Calendar', icon: Calendar },
        { id: 'tasks', label: 'Tasks', icon: CheckSquare },
        { id: 'invoices', label: 'Invoices', icon: FileText },
        { id: 'contracts', label: 'Contracts', icon: FileText },
      ]
    },
    {
      title: 'Tools',
      items: [
        { id: 'contacts', label: 'Contacts', icon: Users },
        { id: 'communications', label: 'Communications', icon: MessageSquare },
        { id: 'files', label: 'Files', icon: FolderOpen },
        { id: 'projects', label: 'Projects', icon: FolderKanban },
      ]
    },
    {
      title: 'Growth',
      items: [
        { id: 'marketing', label: 'Marketing', icon: Megaphone },
        { id: 'revenue', label: 'Revenue', icon: DollarSign },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      ]
    },
    {
      title: 'Team',
      items: [
        { id: 'collaboration', label: 'Collaboration', icon: Users2 },
        { id: 'client-portal', label: 'Client Portal', icon: UserCircle },
      ]
    },
    {
      title: 'System',
      items: [
        { id: 'settings', label: 'Settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-gray-900 text-white flex flex-col">
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <Music className="w-8 h-8 text-purple-400" />
          <div>
            <h1 className="text-xl">Music Biz Pro</h1>
            <p className="text-xs text-gray-400">Business Manager</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 overflow-y-auto">
        {menuSections.map((section, sectionIndex) => (
          <div key={section.title} className={sectionIndex > 0 ? 'mt-6' : ''}>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-2 px-4">
              {section.title}
            </p>
            <ul className="space-y-1">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors text-sm ${
                        activeTab === item.id
                          ? 'bg-purple-600 text-white'
                          : 'text-gray-300 hover:bg-gray-800'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      
      <div className="p-4 border-t border-gray-800">
        <div className="bg-gray-800 rounded-lg p-3">
          <p className="text-xs text-gray-400">Version 1.0.0</p>
          <p className="text-xs text-gray-500 mt-1">© 2025 Music Biz Pro</p>
        </div>
      </div>
    </aside>
  );
}