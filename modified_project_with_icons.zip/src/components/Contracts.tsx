import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { FileText, Plus, Upload, Download, Eye, AlertCircle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type ContractStatus = 'draft' | 'pending' | 'signed' | 'expired' | 'cancelled';
type ContractType = 'performance' | 'recording' | 'publishing' | 'management' | 'licensing' | 'other';

interface Contract {
  id: string;
  title: string;
  type: ContractType;
  party: string;
  startDate: string;
  endDate: string;
  status: ContractStatus;
  value: number;
  description: string;
  signedDate?: string;
  renewalDate?: string;
}

export function Contracts() {
  const [contracts, setContracts] = useState<Contract[]>([
    {
      id: '1',
      title: 'Atlantic Records Recording Agreement',
      type: 'recording',
      party: 'Atlantic Records',
      startDate: '2025-01-01',
      endDate: '2027-12-31',
      status: 'signed',
      value: 250000,
      description: '3-album deal with Atlantic Records',
      signedDate: '2024-12-15',
      renewalDate: '2027-06-30'
    },
    {
      id: '2',
      title: 'Blue Note Performance Agreement',
      type: 'performance',
      party: 'Blue Note Entertainment',
      startDate: '2025-11-15',
      endDate: '2025-11-15',
      status: 'signed',
      value: 2500,
      description: 'Single night performance contract',
      signedDate: '2025-10-20'
    },
    {
      id: '3',
      title: 'Publishing Rights Agreement',
      type: 'publishing',
      party: 'Universal Music Publishing',
      startDate: '2025-06-01',
      endDate: '2026-05-31',
      status: 'pending',
      value: 50000,
      description: 'Publishing rights for new album',
      renewalDate: '2026-03-01'
    },
    {
      id: '4',
      title: 'Management Agreement',
      type: 'management',
      party: 'Star Management Group',
      startDate: '2024-01-01',
      endDate: '2025-12-31',
      status: 'signed',
      value: 75000,
      description: 'Artist management services',
      signedDate: '2023-11-10',
      renewalDate: '2025-09-01'
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');

  const handleCreateContract = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const newContract: Contract = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      type: formData.get('type') as ContractType,
      party: formData.get('party') as string,
      startDate: formData.get('startDate') as string,
      endDate: formData.get('endDate') as string,
      status: 'draft',
      value: parseFloat(formData.get('value') as string) || 0,
      description: formData.get('description') as string
    };

    setContracts([newContract, ...contracts]);
    setIsDialogOpen(false);
    toast.success('Contract created successfully!');
  };

  const getStatusColor = (status: ContractStatus) => {
    switch (status) {
      case 'signed': return 'bg-green-100 text-green-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'expired': return 'bg-red-100 text-red-700';
      case 'draft': return 'bg-gray-100 text-gray-700';
      case 'cancelled': return 'bg-gray-100 text-gray-500';
    }
  };

  const getTypeColor = (type: ContractType) => {
    switch (type) {
      case 'recording': return 'bg-purple-100 text-purple-700';
      case 'performance': return 'bg-blue-100 text-blue-700';
      case 'publishing': return 'bg-orange-100 text-orange-700';
      case 'management': return 'bg-green-100 text-green-700';
      case 'licensing': return 'bg-pink-100 text-pink-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const isExpiringSoon = (endDate: string) => {
    const daysUntilExpiry = Math.ceil((new Date(endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 90 && daysUntilExpiry > 0;
  };

  const filteredContracts = contracts.filter(contract => {
    const statusMatch = filterStatus === 'all' || contract.status === filterStatus;
    const typeMatch = filterType === 'all' || contract.type === filterType;
    return statusMatch && typeMatch;
  });

  const stats = {
    total: contracts.length,
    active: contracts.filter(c => c.status === 'signed').length,
    pending: contracts.filter(c => c.status === 'pending').length,
    expiringSoon: contracts.filter(c => isExpiringSoon(c.endDate) && c.status === 'signed').length
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Contract Management</h1>
          <p className="text-gray-600">Manage and track all your business contracts</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Contract
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Contract</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateContract} className="space-y-4">
              <div>
                <Label>Contract Title</Label>
                <Input name="title" required placeholder="e.g., Recording Agreement" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Contract Type</Label>
                  <Select name="type" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="performance">Performance</SelectItem>
                      <SelectItem value="recording">Recording</SelectItem>
                      <SelectItem value="publishing">Publishing</SelectItem>
                      <SelectItem value="management">Management</SelectItem>
                      <SelectItem value="licensing">Licensing</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Other Party</Label>
                  <Input name="party" required placeholder="Company or individual name" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Start Date</Label>
                  <Input name="startDate" type="date" required />
                </div>
                <div>
                  <Label>End Date</Label>
                  <Input name="endDate" type="date" required />
                </div>
              </div>
              <div>
                <Label>Contract Value ($)</Label>
                <Input name="value" type="number" step="0.01" placeholder="0.00" />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea name="description" rows={3} placeholder="Contract details and terms..." />
              </div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Contract</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Contracts</p>
              <p className="text-3xl">{stats.total}</p>
            </div>
            <FileText className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Active</p>
              <p className="text-3xl">{stats.active}</p>
            </div>
            <CheckCircle2 className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Pending</p>
              <p className="text-3xl">{stats.pending}</p>
            </div>
            <AlertCircle className="w-10 h-10 text-yellow-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Expiring Soon</p>
              <p className="text-3xl">{stats.expiringSoon}</p>
            </div>
            <AlertCircle className="w-10 h-10 text-red-500 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card className="p-4 mb-6">
        <div className="flex gap-4">
          <div className="flex-1">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="signed">Signed</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="performance">Performance</SelectItem>
                <SelectItem value="recording">Recording</SelectItem>
                <SelectItem value="publishing">Publishing</SelectItem>
                <SelectItem value="management">Management</SelectItem>
                <SelectItem value="licensing">Licensing</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Contracts List */}
      <div className="space-y-4">
        {filteredContracts.map((contract) => (
          <Card key={contract.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl">{contract.title}</h3>
                  {isExpiringSoon(contract.endDate) && contract.status === 'signed' && (
                    <Badge className="bg-orange-100 text-orange-700">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Expiring Soon
                    </Badge>
                  )}
                </div>
                <p className="text-gray-600">{contract.party}</p>
              </div>
              <div className="flex gap-2">
                <Badge className={getStatusColor(contract.status)}>
                  {contract.status}
                </Badge>
                <Badge className={getTypeColor(contract.type)}>
                  {contract.type}
                </Badge>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-4">{contract.description}</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
              <div>
                <p className="text-gray-500">Start Date</p>
                <p>{new Date(contract.startDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-gray-500">End Date</p>
                <p>{new Date(contract.endDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-gray-500">Value</p>
                <p>${contract.value.toLocaleString()}</p>
              </div>
              {contract.renewalDate && (
                <div>
                  <p className="text-gray-500">Renewal Date</p>
                  <p>{new Date(contract.renewalDate).toLocaleDateString()}</p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Eye className="w-4 h-4 mr-2" />
                View
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Upload Signed
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredContracts.length === 0 && (
        <Card className="p-12 text-center">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No contracts found</h3>
          <p className="text-gray-600">Try adjusting your filters or create a new contract</p>
        </Card>
      )}
    </div>
  );
}
