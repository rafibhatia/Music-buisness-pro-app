import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { FileText, Plus, DollarSign, Download, Send, Eye } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled';

interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  client: string;
  email: string;
  date: string;
  dueDate: string;
  status: InvoiceStatus;
  items: InvoiceItem[];
  subtotal: number;
  tax: number;
  total: number;
  notes?: string;
}

export function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([
    {
      id: '1',
      invoiceNumber: 'INV-2025-001',
      client: 'Blue Note Entertainment',
      email: 'billing@bluenote.com',
      date: '2025-11-01',
      dueDate: '2025-11-30',
      status: 'sent',
      items: [
        { description: 'Live Performance - Blue Note Jazz Club', quantity: 1, rate: 2500, amount: 2500 }
      ],
      subtotal: 2500,
      tax: 250,
      total: 2750
    },
    {
      id: '2',
      invoiceNumber: 'INV-2025-002',
      client: 'Atlantic Records',
      email: 'payments@atlantic.com',
      date: '2025-11-05',
      dueDate: '2025-11-20',
      status: 'paid',
      items: [
        { description: 'Studio Recording Session', quantity: 6, rate: 300, amount: 1800 }
      ],
      subtotal: 1800,
      tax: 180,
      total: 1980
    },
    {
      id: '3',
      invoiceNumber: 'INV-2025-003',
      client: 'Universal Music Group',
      email: 'billing@umg.com',
      date: '2025-10-15',
      dueDate: '2025-11-14',
      status: 'overdue',
      items: [
        { description: 'Consulting Services', quantity: 4, rate: 250, amount: 1000 }
      ],
      subtotal: 1000,
      tax: 100,
      total: 1100
    }
  ]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const handleCreateInvoice = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const rate = parseFloat(formData.get('rate') as string) || 0;
    const quantity = parseFloat(formData.get('quantity') as string) || 1;
    const subtotal = rate * quantity;
    const tax = subtotal * 0.1;

    const newInvoice: Invoice = {
      id: Date.now().toString(),
      invoiceNumber: `INV-2025-${String(invoices.length + 1).padStart(3, '0')}`,
      client: formData.get('client') as string,
      email: formData.get('email') as string,
      date: formData.get('date') as string,
      dueDate: formData.get('dueDate') as string,
      status: 'draft',
      items: [{
        description: formData.get('description') as string,
        quantity,
        rate,
        amount: subtotal
      }],
      subtotal,
      tax,
      total: subtotal + tax,
      notes: formData.get('notes') as string
    };

    setInvoices([newInvoice, ...invoices]);
    setIsDialogOpen(false);
    toast.success('Invoice created successfully!');
  };

  const getStatusColor = (status: InvoiceStatus) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-700';
      case 'sent': return 'bg-blue-100 text-blue-700';
      case 'overdue': return 'bg-red-100 text-red-700';
      case 'draft': return 'bg-gray-100 text-gray-700';
      case 'cancelled': return 'bg-gray-100 text-gray-500';
    }
  };

  const filteredInvoices = invoices.filter(invoice => {
    return filterStatus === 'all' || invoice.status === filterStatus;
  });

  const stats = {
    total: invoices.reduce((sum, inv) => sum + inv.total, 0),
    paid: invoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.total, 0),
    pending: invoices.filter(inv => inv.status === 'sent').reduce((sum, inv) => sum + inv.total, 0),
    overdue: invoices.filter(inv => inv.status === 'overdue').reduce((sum, inv) => sum + inv.total, 0)
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Invoices & Payments</h1>
          <p className="text-gray-600">Create and manage invoices and track payments</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Invoice
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Invoice</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateInvoice} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Client Name</Label>
                  <Input name="client" required placeholder="Client or company name" />
                </div>
                <div>
                  <Label>Client Email</Label>
                  <Input name="email" type="email" required placeholder="client@example.com" />
                </div>
                <div>
                  <Label>Invoice Date</Label>
                  <Input name="date" type="date" required />
                </div>
                <div>
                  <Label>Due Date</Label>
                  <Input name="dueDate" type="date" required />
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="mb-3">Invoice Items</h3>
                <div className="space-y-3">
                  <div>
                    <Label>Description</Label>
                    <Input name="description" required placeholder="Service or product description" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Quantity/Hours</Label>
                      <Input name="quantity" type="number" step="0.01" defaultValue="1" required />
                    </div>
                    <div>
                      <Label>Rate ($)</Label>
                      <Input name="rate" type="number" step="0.01" required placeholder="0.00" />
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Label>Notes (Optional)</Label>
                <Input name="notes" placeholder="Payment terms, special instructions, etc." />
              </div>

              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Create Invoice</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
              <p className="text-3xl">${stats.total.toLocaleString()}</p>
            </div>
            <DollarSign className="w-10 h-10 text-green-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Paid</p>
              <p className="text-3xl">${stats.paid.toLocaleString()}</p>
            </div>
            <FileText className="w-10 h-10 text-blue-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Pending</p>
              <p className="text-3xl">${stats.pending.toLocaleString()}</p>
            </div>
            <FileText className="w-10 h-10 text-yellow-500 opacity-50" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Overdue</p>
              <p className="text-3xl">${stats.overdue.toLocaleString()}</p>
            </div>
            <FileText className="w-10 h-10 text-red-500 opacity-50" />
          </div>
        </Card>
      </div>

      {/* Filter */}
      <Card className="p-4 mb-6">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Invoices</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="sent">Sent</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </Card>

      {/* Invoices Table */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInvoices.map((invoice) => (
              <TableRow key={invoice.id}>
                <TableCell>{invoice.invoiceNumber}</TableCell>
                <TableCell>
                  <div>
                    <p>{invoice.client}</p>
                    <p className="text-sm text-gray-500">{invoice.email}</p>
                  </div>
                </TableCell>
                <TableCell>{new Date(invoice.date).toLocaleDateString()}</TableCell>
                <TableCell>{new Date(invoice.dueDate).toLocaleDateString()}</TableCell>
                <TableCell>${invoice.total.toLocaleString()}</TableCell>
                <TableCell>
                  <Badge className={getStatusColor(invoice.status)}>
                    {invoice.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {filteredInvoices.length === 0 && (
        <Card className="p-12 text-center mt-6">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl mb-2">No invoices found</h3>
          <p className="text-gray-600">Try adjusting your filters or create a new invoice</p>
        </Card>
      )}
    </div>
  );
}
