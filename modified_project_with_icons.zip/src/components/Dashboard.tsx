import { Card } from './ui/card';
import { Users, MessageSquare, Phone, Mail, Calendar, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';

export function Dashboard() {
  const stats = [
    { label: 'Total Contacts', value: '247', icon: Users, color: 'bg-blue-500' },
    { label: 'Messages Sent', value: '1,234', icon: MessageSquare, color: 'bg-green-500' },
    { label: 'Calls Made', value: '89', icon: Phone, color: 'bg-purple-500' },
    { label: 'Emails Sent', value: '456', icon: Mail, color: 'bg-orange-500' },
  ];

  const recentActivity = [
    { type: 'call', name: 'John Smith', time: '2 hours ago', status: 'completed' },
    { type: 'email', name: 'Sarah Williams', time: '3 hours ago', status: 'sent' },
    { type: 'sms', name: 'Mike Johnson', time: '5 hours ago', status: 'delivered' },
    { type: 'meeting', name: 'Record Label Meeting', time: 'Tomorrow at 2 PM', status: 'scheduled' },
  ];

  const upcomingEvents = [
    { title: 'Studio Session', date: 'Nov 11, 2025', time: '10:00 AM' },
    { title: 'Contract Review', date: 'Nov 12, 2025', time: '2:00 PM' },
    { title: 'Live Performance', date: 'Nov 15, 2025', time: '8:00 PM' },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's what's happening with your music business.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">Recent Activity</h2>
            <TrendingUp className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-3 rounded-lg bg-gray-50">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  activity.type === 'call' ? 'bg-purple-100' :
                  activity.type === 'email' ? 'bg-orange-100' :
                  activity.type === 'sms' ? 'bg-green-100' : 'bg-blue-100'
                }`}>
                  {activity.type === 'call' && <Phone className="w-5 h-5 text-purple-600" />}
                  {activity.type === 'email' && <Mail className="w-5 h-5 text-orange-600" />}
                  {activity.type === 'sms' && <MessageSquare className="w-5 h-5 text-green-600" />}
                  {activity.type === 'meeting' && <Calendar className="w-5 h-5 text-blue-600" />}
                </div>
                <div className="flex-1">
                  <p>{activity.name}</p>
                  <p className="text-sm text-gray-500">{activity.time}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded ${
                  activity.status === 'completed' ? 'bg-green-100 text-green-700' :
                  activity.status === 'sent' || activity.status === 'delivered' ? 'bg-blue-100 text-blue-700' :
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {activity.status}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* Upcoming Events */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">Upcoming Events</h2>
            <Calendar className="w-5 h-5 text-gray-400" />
          </div>
          <div className="space-y-4">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="p-4 rounded-lg border border-gray-200 hover:border-purple-300 transition-colors">
                <h3 className="mb-2">{event.title}</h3>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>{event.date}</span>
                  <span>•</span>
                  <span>{event.time}</span>
                </div>
              </div>
            ))}
            <Button className="w-full" variant="outline">
              <Calendar className="w-4 h-4 mr-2" />
              View Full Calendar
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
