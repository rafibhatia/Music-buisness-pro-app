import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Calendar, FileText, DollarSign, Music, Download, Eye } from 'lucide-react';

export function ClientPortal() {
  const clientInfo = {
    name: 'Blue Note Entertainment',
    contact: 'Michael Johnson',
    email: 'michael@bluenote.com',
    phone: '+1 (555) 123-4567'
  };

  const upcomingEvents = [
    {
      id: '1',
      title: 'Live Performance',
      date: '2025-11-15',
      time: '20:00',
      venue: 'Blue Note Jazz Club',
      status: 'confirmed'
    }
  ];

  const invoices = [
    {
      id: '1',
      number: 'INV-2025-001',
      date: '2025-11-01',
      amount: 2750,
      status: 'sent'
    }
  ];

  const sharedFiles = [
    {
      id: '1',
      name: 'Performance Contract.pdf',
      size: '1.2 MB',
      uploadDate: '2025-10-20'
    },
    {
      id: '2',
      name: 'Set List.pdf',
      size: '245 KB',
      uploadDate: '2025-11-05'
    },
    {
      id: '3',
      name: 'Technical Rider.pdf',
      size: '890 KB',
      uploadDate: '2025-10-25'
    }
  ];

  const communications = [
    {
      id: '1',
      type: 'email',
      subject: 'Performance Confirmation',
      date: '2025-11-01',
      preview: 'Confirming the performance details for November 15th...'
    },
    {
      id: '2',
      type: 'message',
      subject: 'Soundcheck Time Update',
      date: '2025-11-08',
      preview: 'Soundcheck has been moved to 6 PM...'
    }
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Client Portal</h1>
        <p className="text-gray-600">View your bookings, invoices, and shared files</p>
      </div>

      {/* Client Info */}
      <Card className="p-6 mb-6 bg-gradient-to-r from-purple-500 to-blue-500 text-white">
        <div className="flex items-center gap-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback className="bg-white text-purple-600 text-xl">
              {clientInfo.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-2xl mb-1">{clientInfo.name}</h2>
            <p className="opacity-90">{clientInfo.contact}</p>
            <div className="flex gap-4 mt-2 text-sm opacity-90">
              <span>{clientInfo.email}</span>
              <span>•</span>
              <span>{clientInfo.phone}</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Events */}
        <Card className="p-6">
          <h2 className="text-xl mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Upcoming Events
          </h2>
          <div className="space-y-3">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="p-4 rounded-lg border border-gray-200">
                <div className="flex items-start justify-between mb-2">
                  <h3>{event.title}</h3>
                  <Badge className="bg-green-100 text-green-700">{event.status}</Badge>
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>{new Date(event.date).toLocaleDateString()} at {event.time}</p>
                  <p>{event.venue}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Invoices */}
        <Card className="p-6">
          <h2 className="text-xl mb-4 flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Invoices
          </h2>
          <div className="space-y-3">
            {invoices.map((invoice) => (
              <div key={invoice.id} className="p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p>{invoice.number}</p>
                    <p className="text-sm text-gray-600">
                      {new Date(invoice.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg">${invoice.amount.toLocaleString()}</p>
                    <Badge className="bg-blue-100 text-blue-700">{invoice.status}</Badge>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Shared Files */}
        <Card className="p-6">
          <h2 className="text-xl mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Shared Files
          </h2>
          <div className="space-y-2">
            {sharedFiles.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-gray-400" />
                  <div>
                    <p className="text-sm">{file.name}</p>
                    <p className="text-xs text-gray-500">
                      {file.size} • {new Date(file.uploadDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>

        {/* Communications */}
        <Card className="p-6">
          <h2 className="text-xl mb-4 flex items-center gap-2">
            <Music className="w-5 h-5" />
            Recent Communications
          </h2>
          <div className="space-y-3">
            {communications.map((comm) => (
              <div key={comm.id} className="p-4 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors cursor-pointer">
                <div className="flex items-start justify-between mb-1">
                  <h3 className="text-sm">{comm.subject}</h3>
                  <Badge variant="outline" className="text-xs">
                    {comm.type}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-1">{comm.preview}</p>
                <p className="text-xs text-gray-500">
                  {new Date(comm.date).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Help Section */}
      <Card className="p-6 mt-6 bg-gray-50">
        <h3 className="mb-3">Need Help?</h3>
        <p className="text-gray-600 mb-4">
          If you have any questions or need assistance, please don't hesitate to reach out.
        </p>
        <div className="flex gap-3">
          <Button variant="outline">Contact Support</Button>
          <Button variant="outline">Send Message</Button>
        </div>
      </Card>
    </div>
  );
}
