import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/globals.css';

// Electron-specific initialization
if ((window as any).electronAPI) {
  console.log('Running in Electron environment');
  console.log('Platform:', (window as any).electronAPI.platform);
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
