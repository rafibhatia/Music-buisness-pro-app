# ⚡ Quick Commands Reference

## Essential Commands Cheat Sheet

---

## 🚀 First Time Setup

```bash
# 1. Navigate to project folder
cd path/to/music-biz-pro

# 2. Install all dependencies (do this FIRST!)
npm install

# 3. Test it works
npm run dev
```

⏱️ **Time:** ~5 minutes for npm install

---

## 🛠️ Development Commands

### Web Development (Fast, Browser-based)
```bash
npm run dev
```
- Opens http://localhost:5173
- Hot reload enabled
- Fastest for UI work
- Use browser DevTools

### Electron Development (Desktop Preview)
```bash
npm run electron:dev
```
- Opens desktop window
- Hot reload enabled
- Electron DevTools open
- Test desktop features

### Stop Development Server
```
Ctrl + C    (Windows/Linux)
Cmd + C     (macOS)
```

---

## 📦 Build Commands

### Build React App Only
```bash
npm run build
```
- Creates `dist/` folder
- Optimized production build
- Required before Electron build

### Build Desktop App (Current Platform)
```bash
npm run electron:build
```
- Builds for your current OS
- Creates installer in `release/`
- Takes 5-15 minutes first time

### Build for Specific Platform
```bash
# Windows
npm run electron:build:win

# macOS
npm run electron:build:mac

# Linux
npm run electron:build:linux

# All platforms at once
npm run electron:build:all
```

---

## 🎯 Quick Workflows

### "I Just Want to See It"
```bash
npm install
npm run dev
# Open http://localhost:5173
```

### "I Want Desktop Version"
```bash
npm install
npm run electron:dev
```

### "I Want to Build an Installer"
```bash
npm install
# Add icon to public/icon.png
npm run electron:build
# Check release/ folder
```

### "I Made Changes, Test Them"
```bash
npm run dev                    # For web testing
# OR
npm run electron:dev           # For desktop testing
```

### "Create Production Build"
```bash
npm run build                  # Build React app
npm run electron              # Test built version
npm run electron:build        # Create installer
```

---

## 🔧 Maintenance Commands

### Update Dependencies
```bash
npm update
```

### Check for Outdated Packages
```bash
npm outdated
```

### Clear Cache & Reinstall
```bash
rm -rf node_modules package-lock.json
npm install
```

### Check Node & npm Versions
```bash
node --version
npm --version
```

### Lint Code (Check for Errors)
```bash
npm run lint
```

---

## 🗂️ File Operations

### List Files
```bash
ls -la                        # Unix/Mac
dir                           # Windows
```

### Check Disk Space
```bash
du -sh .                      # Unix/Mac
dir /s                        # Windows
```

### Find Large Folders
```bash
du -sh */ | sort -hr          # Unix/Mac
```

---

## 📦 Package Management

### Install Specific Package
```bash
npm install package-name
```

### Install Dev Dependency
```bash
npm install --save-dev package-name
```

### Uninstall Package
```bash
npm uninstall package-name
```

### View Installed Packages
```bash
npm list --depth=0
```

---

## 🐛 Troubleshooting Commands

### Check if Port is Used
```bash
# macOS/Linux
lsof -i :5173

# Windows
netstat -ano | findstr :5173
```

### Kill Process on Port
```bash
# macOS/Linux
lsof -ti:5173 | xargs kill -9

# Windows
taskkill /PID <PID> /F
```

### Clear Vite Cache
```bash
rm -rf node_modules/.vite
```

### Clear All Build Artifacts
```bash
rm -rf dist release node_modules/.vite
```

### Reinstall Everything
```bash
rm -rf node_modules
npm install
```

---

## 🎨 Customization Commands

### Add New Shadcn Component
```bash
npx shadcn-ui@latest add [component-name]
```

### Generate App Icons (if you have icon-gen)
```bash
npx electron-icon-maker --input=./icon.png --output=./build
```

---

## 📊 Information Commands

### View App Version
```bash
node -p "require('./package.json').version"
```

### View Build Configuration
```bash
cat electron-builder.json
```

### View All npm Scripts
```bash
npm run
```

### Check Electron Version
```bash
npx electron --version
```

---

## 🚀 Quick Deploy Workflow

### Local Testing
```bash
npm run dev                    # 1. Test in browser
npm run build                  # 2. Build for production
npm run electron              # 3. Test production build
```

### Create Installers
```bash
npm run electron:build:win     # 4a. Windows installer
npm run electron:build:mac     # 4b. macOS installer
npm run electron:build:linux   # 4c. Linux installers
```

### Verify Build
```bash
ls -lh release/               # Check file sizes
```

---

## 💡 Pro Tips

### Faster Development
```bash
# Use web dev for UI work (faster)
npm run dev

# Use Electron dev only for desktop features
npm run electron:dev
```

### Faster Builds
```bash
# Test build without compression
npm run pack

# Build only for your platform
npm run electron:build
```

### Background Build (Unix/Mac)
```bash
npm run electron:build > build.log 2>&1 &
tail -f build.log
```

---

## 🎯 Command Priority

### Daily Development
```
1. npm run dev              # Most used
2. npm run electron:dev     # Testing desktop
3. Ctrl+C                   # Stop server
```

### Before Sharing
```
1. npm run build           # Build production
2. npm run electron:build  # Create installer
3. Test the installer!     # CRITICAL
```

---

## 📋 Command Checklist for Beginners

First time? Run these in order:

```bash
# Step 1: Setup
✅ cd music-biz-pro
✅ npm install

# Step 2: Test
✅ npm run dev
✅ Open http://localhost:5173
✅ Ctrl+C to stop

# Step 3: Desktop
✅ npm run electron:dev
✅ Ctrl+C to stop

# Step 4: Build
✅ Add icon to public/icon.png
✅ npm run electron:build
✅ Check release/ folder
✅ Test your installer!
```

---

## 🆘 Emergency Commands

### "It's Not Working!"
```bash
rm -rf node_modules
rm package-lock.json
npm install
npm run dev
```

### "Build Failed!"
```bash
npm run build
# Check for errors
# Fix errors
# Try again
```

### "Electron Won't Start!"
```bash
npm install --save-dev electron
npm run electron:dev
```

---

## 🔗 Useful Aliases (Optional)

Add to your `.bashrc` or `.zshrc`:

```bash
alias nrd="npm run dev"
alias nre="npm run electron:dev"
alias nrb="npm run electron:build"
alias ni="npm install"
alias nrs="npm run"
```

Then use:
```bash
ni          # Instead of npm install
nrd         # Instead of npm run dev
nre         # Instead of npm run electron:dev
nrb         # Instead of npm run electron:build
```

---

## 📱 Mobile/Tablet Commands Reference

Save this for quick access on mobile:

```
npm install → npm i
npm run dev → npm run dev
npm run electron:dev → npm run electron:dev
npm run electron:build → npm run electron:build
```

---

## ✅ Quick Verification

### Check Everything is Ready
```bash
# Check Node.js
node --version              # Should be v18+

# Check npm
npm --version              # Should be 8+

# Check files exist
test -f package.json && echo "✅ Package.json exists"
test -f electron-main.js && echo "✅ Electron main exists"

# Check dependencies installed
test -d node_modules && echo "✅ Dependencies installed"

# Check icon added
test -f public/icon.png && echo "✅ Icon exists" || echo "⚠️ Add icon!"
```

---

## 🎉 Success Commands

### After Build Success
```bash
# See what you built
ls -lh release/

# Count files
ls release/ | wc -l

# Check file sizes
du -h release/*
```

---

## 📚 Learn More Commands

```bash
# View command help
npm run --help

# View package info
npm info electron

# View all scripts
npm run

# View dependencies
npm list --depth=0
```

---

## 🎯 Most Important Commands

**Remember these 5:**

1. `npm install` - Install dependencies
2. `npm run dev` - Test in browser
3. `npm run electron:dev` - Test in Electron
4. `npm run electron:build` - Create installer
5. `Ctrl+C` - Stop server

**Everything else is optional!**

---

## 💾 Save This File!

Bookmark this page or print it for quick reference while developing.

**Pro tip:** Keep this open in a separate tab while working! 🚀

---

**Happy coding!** 🎵
