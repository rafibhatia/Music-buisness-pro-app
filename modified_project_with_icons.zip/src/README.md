# 🎵 Music Biz Pro

**A comprehensive music business management platform for musicians, producers, and music professionals.**

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey.svg)

---

## ✨ Features

Music Biz Pro is an all-in-one solution for managing your music business with **18+ powerful features**:

### 📅 **Business Management**
- **Booking Management** - Gigs, studio sessions, meetings, rehearsals
- **Calendar** - Visual schedule with multiple event types  
- **Task Management** - Priority-based to-do lists
- **Invoices** - Professional invoicing and payment tracking
- **Contracts** - Contract management with expiration alerts

### 💬 **Communication**
- **Contacts Database** - Comprehensive contact management
- **Communications Hub** - SMS, Email, Phone calls
- **Virtual Phone Numbers** - Generate business phone lines
- **Team Collaboration** - Shared workspace and notes
- **Client Portal** - Professional client-facing dashboard

### 📈 **Growth & Analytics**
- **Marketing Campaigns** - Campaign management and tracking
- **Revenue Tracking** - Multi-stream income tracking with charts
- **Analytics Dashboard** - Business performance metrics

### 🛠️ **Tools**
- **File Management** - Organize audio, images, documents
- **Project Management** - Track projects and milestones
- **Global Search** - Search across all your data
- **Settings** - Customize your experience

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+ ([Download](https://nodejs.org/))

### Installation

```bash
# 1. Install dependencies
npm install

# 2. Run in development mode
npm run electron:dev

# 3. Build desktop app
npm run electron:build
```

**Your desktop app will be in the `release/` folder!**

📖 **Need detailed instructions?** See [QUICK_START.md](QUICK_START.md)

---

## 🖥️ Platform Support

| Platform | Formats | Architecture |
|----------|---------|--------------|
| **Windows** | `.exe` (installer), `.exe` (portable) | x64, ia32 |
| **macOS** | `.dmg`, `.zip` | Intel (x64), Apple Silicon (arm64) |
| **Linux** | `.AppImage`, `.deb`, `.rpm` | x64 |

---

## 📦 Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start web dev server (browser) |
| `npm run build` | Build production files |
| `npm run electron:dev` | Run Electron in dev mode |
| `npm run electron:build` | Build installer for current platform |
| `npm run electron:build:win` | Build Windows installer |
| `npm run electron:build:mac` | Build macOS installer |
| `npm run electron:build:linux` | Build Linux installers |

---

## 🎨 Customization

### Before Building - Add Your App Icon

1. Create a PNG icon (minimum 512x512, recommended 1024x1024)
2. Save as `public/icon.png`
3. Electron Builder will generate all platform-specific formats

### Update App Information

Edit `package.json`:
```json
{
  "name": "music-biz-pro",
  "version": "1.0.0",
  "author": {
    "name": "Your Name",
    "email": "your.email@example.com"
  }
}
```

Edit `electron-builder.json`:
```json
{
  "appId": "com.yourcompany.musicbizpro",
  "productName": "Your App Name"
}
```

---

## 🏗️ Project Structure

```
music-biz-pro/
├── electron-main.js           # Electron main process
├── electron-preload.js        # Secure preload script
├── electron-builder.json      # Build configuration
├── package.json               # Dependencies & scripts
├── vite.config.ts            # Vite build config
├── src/
│   ├── App.tsx               # Main React component
│   ├── components/           # All feature components
│   │   ├── Dashboard.tsx
│   │   ├── Bookings.tsx
│   │   ├── Calendar.tsx
│   │   ├── Tasks.tsx
│   │   ├── Invoices.tsx
│   │   ├── Contracts.tsx
│   │   ├── Marketing.tsx
│   │   ├── Revenue.tsx
│   │   └── ... (and more)
│   └── styles/               # CSS files
├── public/                   # Static assets
│   └── icon.png             # Your app icon (add this!)
└── release/                  # Built installers (after build)
```

---

## 🔧 Tech Stack

- **Frontend**: React 18 + TypeScript
- **Desktop**: Electron 28
- **Build Tool**: Vite 5
- **Styling**: Tailwind CSS v4
- **UI Components**: Shadcn/ui
- **Icons**: Lucide React
- **Charts**: Recharts
- **Notifications**: Sonner

---

## 📚 Documentation

- 📖 [QUICK_START.md](QUICK_START.md) - Get started in 5 minutes
- 🔧 [ELECTRON_SETUP.md](ELECTRON_SETUP.md) - Complete Electron guide
- ✨ [FEATURES.md](FEATURES.md) - Full feature documentation
- 📦 [NATIVE_PACKAGING_GUIDE.md](NATIVE_PACKAGING_GUIDE.md) - Advanced packaging

---

## 🔐 Security & Backend Integration

### Current State
This is a **frontend prototype** with mock data. For production use:

### Recommended Backend: Supabase
```bash
# Install Supabase client
npm install @supabase/supabase-js
```

Configure in your app:
```typescript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  'YOUR_SUPABASE_URL',
  'YOUR_SUPABASE_KEY'
)
```

### Communication APIs
- **Twilio** - SMS & voice calls
- **SendGrid** - Email delivery
- **Stripe** - Payment processing

**Security Notes:**
- Never store sensitive data in localStorage
- Use environment variables for API keys
- Implement proper authentication
- Follow data protection regulations

---

## 🐛 Troubleshooting

### Common Issues

**"electron: command not found"**
```bash
npm install --save-dev electron
```

**Blank Electron window**
```bash
npm run build
npm run electron
```

**Port 5173 already in use**
```bash
# Kill the process or change port in vite.config.ts
```

**Build takes too long**
- First build: 5-15 minutes (normal)
- Subsequent builds: 2-5 minutes

📖 **More help:** Check [ELECTRON_SETUP.md](ELECTRON_SETUP.md) troubleshooting section

---

## 🤝 Contributing

Contributions welcome! This is a comprehensive music business management platform.

Ideas for contributions:
- Additional features
- Backend integrations
- UI/UX improvements
- Documentation
- Bug fixes

---

## 📄 License

MIT License - see [LICENSE.txt](LICENSE.txt)

---

## 🎯 Roadmap

### Version 1.0.0 (Current) ✅
- All 18+ core features
- Desktop app support
- PWA capabilities

### Version 1.1.0 (Planned)
- Real backend integration (Supabase)
- User authentication
- Data persistence
- Cloud sync

### Version 1.2.0 (Future)
- Mobile app versions
- Real-time collaboration
- Advanced analytics with AI
- Third-party integrations
- Automated email campaigns

---

## 🙏 Acknowledgments

Built with:
- React & TypeScript
- Electron & Electron Builder
- Vite
- Tailwind CSS
- Shadcn/ui components
- And many other amazing open-source projects

---

## 📞 Support

- 📖 Documentation: See docs folder
- 🐛 Issues: Report via your issue tracker
- 💬 Discussions: For questions and ideas
- 📧 Email: your.email@example.com

---

## ⭐ Show Your Support

If you find this project useful, please consider:
- Giving it a star ⭐
- Sharing it with other musicians
- Contributing improvements
- Reporting bugs

---

**Built for musicians, by musicians** 🎵

Made with ❤️ using React, Electron, and modern web technologies.

---

## 🏁 Next Steps

1. ✅ Run `npm install`
2. ✅ Add your app icon to `public/icon.png`
3. ✅ Customize branding in `package.json`
4. ✅ Run `npm run electron:dev` to test
5. ✅ Run `npm run electron:build` to create installer
6. 🚀 Share your music business management app!

**Happy managing!** 🎸🎹🎤🥁
